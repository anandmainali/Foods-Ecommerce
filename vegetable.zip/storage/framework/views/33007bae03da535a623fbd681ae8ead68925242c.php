
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard</title>
    
    <!-- google font -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&amp;subset=all" rel="stylesheet" type="text/css" />  
    <!-- icons -->
    <link href="<?php echo e(asset('bootstrap/js/simple-line-icons/simple-line-icons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.2.0/min/dropzone.min.css" rel="stylesheet">
    
    <!--bootstrap -->
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-switch/3.3.4/css/bootstrap3/bootstrap-switch.min.css" rel="stylesheet">
    
    
    <!-- data tables -->
    <link href="<?php echo e(asset('bootstrap/js/datatables/jquery.dataTables.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css"/>
    

    <!-- Theme Styles -->
    <link href="<?php echo e(asset('bootstrap/css/theme_style.css')); ?>" id="rt_style_components" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/plugins.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/responsive.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/css/theme-color.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bootstrap/js/summernote/summernote.css')); ?>" rel="stylesheet">
    
    <!-- Editor -->
     <!-- <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
         <script>tinymce.init({ selector:'textarea' });</script> -->
         <script src="//cdn.ckeditor.com/4.8.0/full/ckeditor.js"></script>
         <style>
         .sidemenu {
            overflow-y: scroll;
            height: 600px;
        }
    </style>

    <!-- favicon -->
    <link rel="shortcut icon" href="" /> 
</head>
<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-blue">
   

    <div class="page-wrapper">
        <!-- start header -->
        <div class="page-header navbar navbar-fixed-top">
            <div class="page-header-inner ">
             <!-- logo start -->
             <div class="page-logo">
                <a href="">
                    <span class="logo-icon fa fa-shopping-cart fa-rotate-45"></span>
                    <span class="logo-default" >Admin</span> </a>
                </div>
                <!-- logo end -->
                <ul class="nav navbar-nav navbar-left in">
                    <li><a href="javascript:void(0)" class="menu-toggler sidebar-toggler"><i class="icon-menu"></i></a></li>
                    
                </ul>
                <!-- start mobile menu -->
                <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
                    <span></span>
                </a>
                <!-- end mobile menu -->
                <!-- start header menu -->
                <div class="top-menu">

                    <ul class="nav navbar-nav pull-right">
                        
                        
                        
                        <!-- start manage user dropdown -->
                        <li class="dropdown dropdown-user">
                            
                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                <?php if(Auth::check()): ?>
                                    <?php if(Auth::user()->image): ?>
                                        <img src="<?php echo e(Auth::user()->image); ?>" alt="" class="img-circle" />
                                    <?php else: ?>
                                        <img src="/UserImage/default.png" alt="" class="img-circle" />
                                    <?php endif; ?>
                                <span class="username username-hide-on-mobile"><?php echo e(Auth::user()->uname); ?></span>
                                <i class="fa fa-angle-down"></i>
                                <?php endif; ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-default">
                                <li>
                                    <a href="<?php echo e(route('index')); ?>">
                                        <i class="fa fa-globe"></i> Visit Home </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('profile')); ?>">
                                            <i class="icon-user"></i> Profile </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('setting')); ?>">
                                                <i class="icon-settings"></i> Settings
                                            </a>
                                        </li>
                                        
                                        <li class="divider"> </li>
                                        
                                        <li>
                                            <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                                            <i class="fa fa-power-off"></i> Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                    
                                </ul>
                            </li>
                            <!-- end manage user dropdown -->
                            
                        </ul>
                    </div>
                </div>
            </div>
            <!-- end header -->
            
            <!-- start page container -->
            <div class="page-container">
                <!-- start sidebar menu -->
                
                <div class="sidebar-container">
                    <div class="sidemenu-container navbar-collapse collapse fixed-menu">
                        <div id="remove-scroll">
                            <ul class="sidemenu  page-header-fixed" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
                                <li class="sidebar-toggler-wrapper hide">
                                    <div class="sidebar-toggler">
                                        <span></span>
                                    </div>
                                </li>
                                <li class="sidebar-user-panel">
                                    <div class="user-panel">
                                        <div class="pull-left image">
                                            <?php if(Auth::user()->image): ?>
                                        <img src="<?php echo e(Auth::user()->image); ?>" alt="" class="img-circle" />
                                    <?php else: ?>
                                        <img src="/UserImage/default.png" alt="" class="img-circle" />
                                    <?php endif; ?>                                            
                                        </div>
                                        <div class="pull-left info">
                                            <p> <?php echo e(Auth::user()->uname); ?></p>
                                            <p><?php echo e(ucfirst(Auth::user()->utype)); ?></p>
                                            
                                        </div>
                                    </div>
                                </li>
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin')); ?>" class="nav-link "> <i class="fa fa-tachometer"></i> <span class="title">Dashboard</span>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="<?php echo e(url('/admin/order')); ?>" class="nav-link "> <i class="fa fa-shopping-cart" aria-hidden="true"></i> <span class="title">Orders</span>
                                    </a>
                                </li>
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('product.index')); ?>" class="nav-link "> <i class="fa fa-shopping-basket" aria-hidden="true"></i> <span class="title">Products</span>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="<?php echo e(route('category.index')); ?>" class="nav-link "> <i class="fa fa-list-alt" aria-hidden="true"></i> <span class="title">Categories</span>
                                    </a>
                                </li>

                                <!-- <li class="nav-item">
                                    <a href="<?php echo e(route('subcategory.index')); ?>" class="nav-link "> <i class="fa fa-tags" aria-hidden="true"></i> <span class="title">Sub-Categories</span>
                                    </a>
                                </li> -->
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('slider.index')); ?>" class="nav-link "> <i class="fa fa-file-photo-o" aria-hidden="true"></i> <span class="title">Slider</span>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="<?php echo e(route('member.index')); ?>" class="nav-link "> <i class="fa fa-users"></i>
                                        <span class="title">Team Members</span> 
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="<?php echo e(route('customer.index')); ?>" class="nav-link "> <i class="fa fa-user"></i> <span class="title">Testimonials</span>
                                    </a>
                                </li>


                                <li class="nav-item">
                                    <a href="<?php echo e(route('comment.index')); ?>" class="nav-link "> <i class="fa fa-comment"></i> <span class="title">Comments</span>
                                    </a>
                                </li>

                                <?php if(Auth::user()->utype === 'admin'): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('user.index')); ?>" class="nav-link ">  <i class="fa fa-user"></i>
                                        <span class="title">Users</span>
                                    </a>
                                </li>
                                <?php endif; ?>
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.info')); ?>" class="nav-link "> <i class="fa fa-info-circle"></i> <span class="title">Site Info.</span>
                                    </a>
                                </li>

                            </ul>
                            

                        </div>
                    </div>
                </div>
                <!-- end sidebar menu --> 
                <div class="page-content-wrapper">
                    <div class="page-content">
                        <div class="page-bar">
                            <div class="page-title-breadcrumb">
                                <div class=" pull-left">
                                    <div class="page-title"><?php echo $__env->yieldContent('breadcrumb'); ?></div>
                                    <?php if(session()->has('success')): ?>
                                    <div class="alert alert-success"><i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo e(session()->get('success')); ?></div>
                                    <?php endif; ?>
                                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <?php echo e($error); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <ol class="breadcrumb page-breadcrumb pull-right">
                                    <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="<?php echo e(route('admin')); ?>">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                    </li>
                                    
                                    <li class="active"><?php echo $__env->yieldContent('breadcrumb'); ?></li>
                                </ol>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card card-topline-aqua">
                                    <div class="card-head">
                                        <header></header>
                                        <div class="tools">
                                            <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                                            <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                                            <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                                        </div>
                                    </div>

                                    <?php echo $__env->yieldContent('content'); ?>

                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end page container -->

            <!-- start footer -->
            <div class="page-footer">
                <div class="page-footer-inner"> <h4>Developed By The Team of BIT.</h4>
                </div>
                <div class="scroll-to-top">
                    <i class="icon-arrow-up"></i>
                </div>
            </div>
            <!-- end footer -->
        </div>
        <script src="<?php echo e(asset('bootstrap/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/counterup/jquery.waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/counterup/jquery.counterup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/app.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/layout.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/theme-color.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/login.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/pages.js')); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-switch/3.3.4/js/bootstrap-switch.min.js"></script>
        <!-- Dropzone  -->   
        <script src="<?php echo e(asset('bootstrap/js/dropzone.js')); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.2.0/min/dropzone.min.js"></script>
        <script src="<?php echo e(asset('bootstrap/js/summernote/summernote.js')); ?> " type="text/javascript"></script>
        <!--  DataTables -->
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
        
        <script type="text/javascript">
            $(document).ready(function() {
                $('#about').summernote();          

            });
        </script>
        <script type="text/javascript">
            $(document).ready(function() {
                $('#info').summernote();          

            });
        </script>
        <script>
            $(document).ready( function () {
                $('#example4').DataTable();
            } );
        </script>
        <script>
            $("[name='featured']").bootstrapSwitch();
            $("[name='shipping_status']").bootstrapSwitch();
        </script>

    </body>

    </html>
    
    
    
