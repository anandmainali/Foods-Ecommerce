<?php $__env->startSection('content'); ?>


    <div class="page-content-wrapper">
        <div class="page-content">

            <div class="page-bar">
                <div class="page-title-breadcrumb">
                    <div class=" pull-left">
                        <div class="page-title">User Profile</div>
                    </div>
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="<?php echo e(route('admin')); ?>">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                        </li>
                        
                        <li class="active">User Profile</li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <!-- BEGIN PROFILE SIDEBAR -->
                    <div class="profile-sidebar">
                        <div class="card card-topline-aqua">
                            <div class="card-body no-padding height-9">
                                <div class="row">
                                    <div class="profile-userpic">
                                        <img src="<?php echo e(Auth::user()->image); ?>" class="img-responsive" alt=""> </div>
                                </div>
                                <br>
                                <ul class="list-group list-group-unbordered">
                                    <li class="list-group-item">
                                        <b>Username</b> <a class="pull-right"><?php echo e(Auth::user()->uname); ?></a>
                                    </li>
                                    <li class="list-group-item">
                                        <b>Email</b> <a class="pull-right"><?php echo e(Auth::user()->email); ?></a>
                                    </li>
                                    <li class="list-group-item">
                                        <b>User Type</b> <a class="pull-right"><?php echo e(ucfirst(Auth::user()->utype)); ?></a>
                                    </li>
                                </ul>
                                <!-- END SIDEBAR USER TITLE -->

                            </div>
                        </div>

                    </div>
                    <!-- END BEGIN PROFILE SIDEBAR -->


                </div>
            </div>
            <!-- end page content -->

        </div>
    </div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>