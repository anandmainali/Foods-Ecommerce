<?php $__env->startSection('content'); ?>



    <!-- start page content -->
    <div class="page-content-wrapper">
        <div class="page-content">
            <div class="page-bar">
                <div class="page-title-breadcrumb">
                    <div class=" pull-left">
                        <div class="page-title">Users List</div>
                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success"><i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo e(session()->get('success')); ?></div>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
            <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary" role="button"><i class="fa fa-plus" aria-hidden="true"></i> Add User</a>
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-topline-red">
                        <div class="card-head">
                            <header></header>
                            <div class="tools">
                                <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                                <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                                <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                            </div>
                        </div>
                        <div class="card-body ">

                            <table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle" id="example4">
                                <thead>
                                <tr>
                                    <th>S.N.</th>
                                    <th>Image</th>
                                    <th> User Name </th>
                                    <th> Email </th>
                                    <th> Role </th>
                                    <th> Status </th>
                                    <th> Action </th>
                                </tr>
                                </thead>
                                <?php if(count($users) > 0): ?>
                                    <tbody>

                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="odd gradeX">
                                            <td><?php echo e(++$key); ?></td>
                                            <td><img src="<?php echo e($user->image); ?>" alt="" height="80px"></td>
                                            <td><?php echo e($user->uname); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td><?php echo e(ucfirst($user->utype)); ?></td>
                                            <td>      
                                            <?php if($user->status == 0): ?>
                                            <span class="label label-danger">
                                                Disabled
                                            </span>  
                                            <?php else: ?>
                                            <span class="label label-success">
                                                Enabled
                                            </span>  
                                            <?php endif; ?>                                         
                                                                               
                                            </td>
                                            <td>
                                                <?php echo Form::open(['method'=>'DELETE','action'=>['UserController@destroy',$user->id]]); ?>

                                                <?php echo Form::button('<i class="fa fa-trash"></i> Delete',['type'=>'submit','class'=>'btn btn-danger','return onClick'=>'confirm("Are you sure to delete?")']); ?>

                                                <?php echo Form::close(); ?>

                                                <a href='<?php echo e(route('user.edit',$user->id)); ?>'>
                                                    <button class="btn btn-primary btn-sm">
                                                        <i class="fa fa-edit"></i> Edit
                                                    </button>
                                                </a>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                <?php else: ?>

                                    <tr>
                                        <td colspan="6"> No Users Found.</td>
                                    </tr>
                                <?php endif; ?>
                            </table>
                            <div class="paginate pull-right">
                                <?php echo e($users->links()); ?>

                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end page content -->










<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>