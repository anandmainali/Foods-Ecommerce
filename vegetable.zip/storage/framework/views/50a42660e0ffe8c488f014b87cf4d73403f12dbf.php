    <?php $__env->startSection('content'); ?>
    <div class="page-content-wrapper">
        <div class="page-content">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-topline-red">                                
                        <div class="card-body ">
                            <h1 class="page-header"><i class="fa fa-hospital-o fa-lg" aria-hidden="true"></i> Hospital Info
                            </h1>
 <?php echo Form::model($info,['method'=>'PATCH','action'=>'AdminController@updateInfo']); ?>


        <div class="form-group">
            <?php echo Form::label('name','Hospital Name'); ?>

            <?php echo Form::text('name',null,['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('email','Email'); ?>

            <?php echo Form::email('email',null,['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('phone','Phone'); ?>

            <?php echo Form::text('phone',null,['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('address','Address'); ?>

            <?php echo Form::text('address',null,['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('about','Description'); ?>

            <?php echo Form::textarea('about',null,['class'=>'form-control']); ?>

        </div>
                <div class="form-group">
            <?php echo Form::label('notice','Notice'); ?>

            <?php echo Form::textarea('notice',null,['class'=>'form-control']); ?>

        </div>

        <div class="form-group">                        
            <?php echo Form::submit('Submit',['class'=>'btn btn-primary pull-right']); ?>

        </div>


<?php echo Form::close(); ?>



                       


 
                    </div>
                 </div>
                            </div>
                        </div>
                            </div>
                        </div>

        <?php $__env->stopSection(); ?>



            
            

                   
                        





                        

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>