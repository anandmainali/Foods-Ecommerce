<?php $__env->startSection('body'); ?>

<?php echo $__env->make('project.include.bread-crumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- confirm start here -->
    <div class="confirm">
        <div class="container">
            <div class="row">
               
                <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                    <div class="image">
                        <img  src="<?php echo e(URL::to('project/images/confirmation.png')); ?>" class="img-responsive" alt="confirm" title="confirm" />
                    </div>
                    <h2>Order successfully Received</h2>
                    <p>Thank For Your Purchase</p>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 text-center">
                    <div class="buttons">
                        <button type="button" class="btn-primary" onclick="location.href='<?php echo e(route('index')); ?>'">Return to home</button>
                        <button type="button" class="btn-primary" onclick="location.href='<?php echo e(route('shop')); ?>'">continue shopping</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- confirm end here -->


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('project.pages.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>