


<!--footer end here -->

<!-- jquery -->
<script src="<?php echo e(URL::to('/project/js/jquery.2.1.1.min.js')); ?>"></script>
<!-- bootstrap js -->
<script src="<?php echo e(URL::to('/project/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!--bootstrap select-->
<script src="<?php echo e(URL::to('/project/js/dist/js/bootstrap-select.js')); ?>"></script>
<!--internal js-->
<script src="<?php echo e(URL::to('/project/js/internal.js')); ?>"></script>
<!-- owlcarousel js -->
<script src="<?php echo e(URL::to('/project/js/owl-carousel/owl.carousel.min.js')); ?>"></script>
</body>

</html>
