<?php $__env->startSection('breadcrumb','Category List'); ?>
<?php $__env->startSection('content'); ?>
<div class="card-body ">
	<div class="row">
		<div class="col-md-6 col-sm-6 col-xs-6">
			<div class="btn-group">
				<a href="<?php echo e(route('category.create')); ?>" class="btn btn-info" role="button"><i class="fa fa-plus" aria-hidden="true"></i> Add New</a>
			</div>
		</div>

	</div>
	<table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle" id="example4">
		<thead>
			<tr>
				<th>S.N.</th>
				<th> Name </th>				                                                
				<th> Action </th>
			</tr>
		</thead>
		<tbody>
			<?php if(count($categories) > 0): ?>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr class="odd gradeX">
				<td class="patient-img">
					<?php echo e(++$key); ?>

				</td>
				<td><?php echo e($category->name); ?></td>
<td style="width: 100px;">
          <div style="float: left;">
            <a href='<?php echo e(route('category.edit',$category->id)); ?>'>
              <button class="btn btn-primary btn-xs">
                <i class="fa fa-edit"></i>
              </button>
            </a>
          </div>
          <div style="float: right;">
            <?php echo Form::open(['method'=>'DELETE','action'=>['CategoryController@destroy',$category->id]]); ?>

            <?php echo Form::button('<i class="fa fa-trash"></i>',['type'=>'submit','class'=>'btn btn-danger btn-xs','return onClick'=>'confirm("Are you sure to delete?")']); ?>

            <?php echo Form::close(); ?>

          </div>
        </td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</tbody>
		<?php else: ?>
    <tr>
      <td colspan="100%"><h4>Category Table is Empty.</h4></td>
    </tr>
    <?php endif; ?>
	</table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>