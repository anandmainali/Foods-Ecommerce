<?php $__env->startSection('breadcrumb','Create Product'); ?>
<?php $__env->startSection('content'); ?>
<div class="card-body ">
   <div class="row">

   	<?php echo Form::open(['method'=>'POST','action'=>'ProductController@store','files'=>true]); ?>

    <div class="col-md-12">
    	<div class="form-group">
            <?php echo Form::label('category_id','Category'); ?>

            <?php echo Form::select('category_id', $category, null,['class'=>'form-control']);; ?>

        </div> 
       <!--  <div class="form-group">
           <?php echo Form::label('subcategory_id','Subcategory'); ?>

           <?php echo Form::select('subcategory_id', $subcategory, null,['class'=>'form-control']);; ?>

       </div>  -->
        <div class="form-group">
            <?php echo Form::label('name','Name'); ?>

            <?php echo Form::text('name',null,['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('discount','Discount (%)'); ?>

            <?php echo Form::text('discount',null,['class'=>'form-control']); ?>

        </div>
         <div class="form-group">
            <?php echo Form::label('oldprice','Old Price (Rs.)'); ?>

            <?php echo Form::text('oldprice',null,['class'=>'form-control']); ?>

        </div>
         <div class="form-group">
            <?php echo Form::label('newprice','New Price (Rs.)'); ?>

            <?php echo Form::text('newprice',null,['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('unit','Unit (Eg: Kg,Pcs)'); ?>

            <?php echo Form::text('unit',null,['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('image','Photo'); ?>

            <?php echo Form::file('image',['class'=>'form-control']); ?>

        </div>
         <div class="form-group">
            <?php echo Form::label('featured','Featured'); ?> <br>
            <?php echo Form::checkbox('featured',1,null,['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('description','Description'); ?>

            <?php echo Form::textarea('description',null,['class'=>'form-control','id'=>'about']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::button('<i class="fa fa-paper-plane"></i>Submit',['type'=>'submit','class'=>'btn btn-primary pull-right']); ?>

        </div>
        <a type="cancel" href="<?php echo e(route('product.index')); ?>" class="btn btn-default pull-right">Cancel</a>
    </div>

    <?php echo Form::close(); ?>



</div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>