
 <!-- bootstrap carousel -->

    <?php $__env->startSection('content'); ?> 
<div class="custom-breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h3>You can find Dr. Arun Kumar Gupta in following places,</h3>
                    </div>
                </div>

            </div>
        </div><!--breadcrumb-->
        <div class="divide70"></div>

        <?php foreach ($associations as $key => $association)    : ?>
        <section class="testimonials">
        <div class="container">
        <div class="row">
            <div class="col-sm-3"> 
                <?php if($association->image): ?>
                      <img src="<?php echo e($association->image); ?>" class="img-thumbnail img-responsive doctor" alt="">
                <?php else: ?>
                     <img src="/Images/logo/hospital.png" class="img-thumbnail img-responsive doctor" alt="" />
                <?php endif; ?>
                   
                        
            
           
                    </div>
                    <div class="col-sm-9"><br>
                    <h3><?= $association->name ?></h3>                    
                    <strong><i class="fa fa-map-marker fa-lg" aria-hidden="true"></i> Location:</strong> <?= $association->address ?> <br>
                    <strong><i class="fa fa-phone fa-lg" aria-hidden="true"></i> Contact No.: </strong> <?= $association->phone ?> <br>
                    <strong><i class="fa fa-info-circle" aria-hidden="true"></i> Information:</strong><br> <?= $association->info ?><br>   
                    </div>                 
                    
        </div>
        </div>
       </section>
        <div class="divide70"></div>
    <?php endforeach; ?>
        
       <br><br><br>
        
        <!--know more section end-->
        <?php echo $__env->make('layouts.includes.appointment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    

         <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.home-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>