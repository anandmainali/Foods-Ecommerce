<?php $__env->startSection('body'); ?>

    <?php echo $__env->make('project.include.bread-crumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- register start here -->
    <div class="register">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3 col-sm-offset-3">
                    <div class="commontop text-left">
                        <h4>
                            Create your account
                            <i class="icon_star_alt"></i>
                            <i class="icon_star_alt"></i>
                            <i class="icon_star_alt"></i>
                        </h4>
                    </div>
                    <p>Create your new account</p>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('uname') ? ' has-error' : ''); ?>">
                            <label for="uname">Full Name*</label>                            
                                <input id="name" type="text" class="form-control" name="uname" value="<?php echo e(old('uname')); ?>" required autofocus>
                                <?php if($errors->has('uname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('uname')); ?></strong>
                                    </span>
                                <?php endif; ?>                         
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email">Email Address *</label>                            
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>                            
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password">Password*</label>

                           
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                           
                        </div>

                        <div class="form-group">
                            <label for="password-confirm">Confirm Password*</label>
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            
                        </div>

                        <div class="form-group">
                            
                                <button type="submit" class="btn btn-primary">
                                    Register
                                </button>
                                <button class="btn btn-primary pull-right" type="button" onclick="location.href='<?php echo e(route('signin')); ?>'">SignIn <i class="fa fa-arrow-right"></i></button>
                           
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- register end here -->


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('project.pages.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>