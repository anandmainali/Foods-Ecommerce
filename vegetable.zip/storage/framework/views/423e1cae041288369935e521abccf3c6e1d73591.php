<?php $__env->startSection('breadcrumb','Slider List'); ?>
<?php $__env->startSection('content'); ?>

                    <div class="card-body ">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <div class="btn-group">
                                    <a href="<?php echo e(route('slider.create')); ?>" class="btn btn-info" role="button"><i class="fa fa-plus" aria-hidden="true"></i> Add New</a>
                                </div>
                            </div>                                                      
                        </div>

                        <table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle" id="example4">
                            <thead>

                                <tr>
                                    <th>S.N.</th>
                                    <th>Image</th>                                                                        
                                    <th>Action</th>                               
                                </tr>
                            </thead>
                            
                            <tbody>
                               <?php if(count($sliders) > 0): ?>
                               <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr>	
                                <td><?php echo e(++$key); ?></td>                               
                                <td><img src="<?php echo e($slider->image); ?>" height="100px" alt=""></td>
                                <td style="width: 80px;">
                                    <?php echo Form::open(['method'=>'DELETE','action'=>['SliderController@destroy',$slider->id]]); ?>

                                    <?php echo e(Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs','onClick'=>'return confirm("Are you sure to delete?")'])); ?>

                                    <?php echo Form::close(); ?>


                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                        <?php else: ?>
                        <tr>
                            <td colspan="100%"><h4>Slider Table is Empty.</h4></td>
                        </tr>
                        <?php endif; ?>                          
                    </table>
                </div>
            
<?php $__env->stopSection(); ?>









<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>