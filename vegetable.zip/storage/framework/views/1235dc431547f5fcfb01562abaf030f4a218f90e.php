    
    <?php $__env->startSection('breadcrumb','Setting'); ?>
    <?php $__env->startSection('content'); ?>
    <div class="card-body">   
        <div class="row">
            <div class="col-md-12">                          
                <div class="col-md-4">
                    <?php if(Auth::user()->image): ?>
                    <img src="<?php echo e(Auth::user()->image); ?>" style="margin-top: 20px" class="img-responsive thumbnail" alt="">
                    <?php else: ?>
                    <img src="\UserImage\default.png" style="margin-top: 20px" class="img-responsive thumbnail" alt="">
                    <?php endif; ?>
                    
                </div>
                <div class="col-md-8 col-sm-8">
                    <div class="panel tab-border card-topline-green">
                        <header class="panel-heading panel-heading-gray custom-tab">
                            <ul class="nav nav-tabs">                                        
                                <li class="active">
                                    <a href="#about-2" data-toggle="tab">
                                        <i class="fa fa-edit"></i> Update Profile
                                    </a>
                                </li>
                                <li class="">
                                    <a href="#contact-2" data-toggle="tab">
                                        <i class="fa fa-lock"></i> Update Password
                                    </a>
                                </li>
                            </ul>
                        </header>
                        <div class="panel-body">
                            <div class="tab-content">
                                <div class="tab-pane " id="home-2">Home</div>
                                <div class="tab-pane active" id="about-2">
                                    <div class="card-body " id="bar-parent">

                                        <?php echo Form::model(Auth::user(),['method'=>'PATCH','action'=>['AdminController@updateUser',Auth::user()->id],'files'=>true]); ?>


                                        <div class="form-group">
                                            <?php echo Form::label('uname','Username'); ?>

                                            <?php echo Form::text('uname',null,['class'=>'form-control']); ?>

                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('email','Email'); ?>

                                            <?php echo Form::email('email',null,['class'=>'form-control']); ?>

                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('image','Photo'); ?>

                                            <?php echo Form::file('image',['class'=>'form-control']); ?>

                                        </div>                               

                                        <div class="form-group">                        
                                            <?php echo Form::button('<i class="fa fa-paper-plane"></i>Update',['type'=>'submit','class'=>'btn btn-primary pull-right']); ?>

                                        </div>


                                        <?php echo Form::close(); ?> 
                                    </div>

                                </div>
                                <div class="tab-pane " id="contact-2">
                                    <div class="card-body " id="bar-parent">
                                        <?php echo Form::open(['method'=>'POST','action'=>['AdminController@updatePassword',Auth::user()->id]]); ?> 

                                        <div class="form-group">
                                            <?php echo Form::label('oldPassword','Old Password'); ?>

                                            <?php echo Form::password('oldPassword',['class'=>'form-control']); ?>

                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('newPassword','New Password'); ?>

                                            <?php echo Form::password('newPassword',['class'=>'form-control']); ?>

                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('confirmPassword','Confirm Password'); ?>

                                            <?php echo Form::password('confirmPassword',['class'=>'form-control']); ?>

                                        </div>

                                        <div class="form-group">                        
                                            <?php echo Form::button('<i class="fa fa-paper-plane"></i>Update',['type'=>'submit','class'=>'btn btn-primary pull-right']); ?>

                                        </div>
                                        
                                        
                                        <?php echo Form::close(); ?> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
                

                <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>