<?php $__env->startSection('content'); ?>




                <div class="page-content-wrapper">
                <div class="page-content">
                
 <div id="page-wrapper">
            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header" align="center">
                            View Photos                        
                        </h1>
                        


                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Image Title</th>
                                    <th>Image</th>                                     
                                    <th>Action</th>                               
                                </tr>
                            </thead>
                            
                            <tbody>
                            <td></td>
                            <td></td>
                            <td>
                                <img src="" width="80" alt="">
                            </td>
                            <td>
                                    <a href=''>
                                        <button class="btn btn-danger btn-sm"
                                                onclick="return confirm('Are you sure you want to delete?')">
                                            <i class="fa fa-trash"></i> Delete
                                        </button>
                                    </a>
                                </td>


                            </tbody>
                        
                        <tr>
                            <td colspan="100%"><h3>No photos found.</h3></td>
                        </tr>
                 
                        </table>
                         
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



                        
                        





                                     

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>