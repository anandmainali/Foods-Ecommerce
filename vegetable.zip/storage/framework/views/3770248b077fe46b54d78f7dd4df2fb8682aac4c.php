<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Arthritis Care Center</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/owl.carousel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/owl.theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/flexslider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/magnific-popup.css')); ?>">    
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/front-style.css')); ?>">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <div class="top">
            <div class="row">
                   
                    <div class="col-sm-6 ">
                        <ul class="list-inline">
                            <li><i class="fa fa-phone"></i> 6456456464</li>
                        </ul>
                    </div>
                    <div class="col-sm-6">
                        <ul class="list-inline pull-right">                        
                            <li><i class="fa fa-envelope-o"></i> uraj@gmail.com</li>
                            
                        </ul>                        
                    </div>
                </div>
                </div>


    <div class="container">
    <div class="row">
          <div class="col-sm-2 logo"><a href=""><img src="" alt=""></a></div>
          <div class="col-sm-10 banner"><img src="" alt="" class="img-responsive"></div>
    </div>
    </div>

    <!-- Navigation -->

<nav id="navigation" class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="">Home</a></li>
                        <li><a href="">Disorder We Treat</a></li>
                        <li><a href="">Make an appointment</a></li>   
                        <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">About <span class="caret"></span></a>               
              <ul class="dropdown-menu" role="menu">
                <li><a href="">Find Dr. Arun Kumar Gupta</a></li>
                <li class="divider"></li>
                <li><a href="">What is a Rheumatologist?</a></li>
                <li class="divider"></li>
                <li><a href="">What is a Arthritis?</a></li>
                <li class="divider"></li>
                <li><a href="">Meet Our Team</a></li>
                
                
              </ul>                
            </li>                      
                        
                        <li><a href="">Gallery</a></li>
                        <li><a href="">Contact us</a></li>
                       
                            <li><a href=''>Admin</a></li>
                            <li><a href=''>LogOut</a></li>
                                                 
                    </ul>
                </div><!--/.nav-collapse -->
            </div><!--/.container-fluid -->
        </nav>
        <br>


























<footer class="footer">
             <div class="divide40"></div>
             <div class="socials-colored col-md-12 center">
                <a href="#" class="social-icon social-ico-dark social-ico-colored-facebook">
                    <i class="fa fa-facebook"></i>
                    <i class="fa fa-facebook"></i>
                </a>
                <a href="#" class="social-icon social-ico-dark social-ico-colored-twitter">
                    <i class="fa fa-twitter"></i>
                    <i class="fa fa-twitter"></i>
                </a>
                <a href="#" class="social-icon social-ico-dark social-ico-colored-google-plus">
                    <i class="fa fa-google-plus"></i>
                    <i class="fa fa-google-plus"></i>
                </a>
                <a href="#" class="social-icon social-ico-dark social-ico-colored-youtube">
                    <i class="fa fa-youtube-play"></i>
                    <i class="fa fa-youtube-play"></i>
                </a>
                <a href="#" class="social-icon social-ico-dark social-ico-colored-linkedin">
                    <i class="fa fa-linkedin"></i>
                    <i class="fa fa-linkedin"></i>
                </a>
            </div>
            <div class="footer-copyright">
                <div class="container">
                    <span>Copyright &copy; 2017. All right reserved.</span>
                </div>
            </div>
        </footer>
        <script src="<?php echo e(asset('bootstrap/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/frontend/jquery-migrate.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/frontend/jquery.flexslider-min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/frontend/jquery.stellar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/frontend/jquery.magnific-popup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/frontend/wow.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/frontend/custom.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/frontend/jquery.tickerNews.min.js')); ?>"></script>
       

       <!--gmap js-->

        <script>
      var map;
      function initMap() {
    
    var broadway = {
        info: '<strong>Chipotle on Broadway</strong><br>\
                    5224 N Broadway St<br> Chicago, IL 60640<br>\
                    <a href="https://www.google.com/maps/dir//T.U.Teaching+Hospital/@27.735746,85.3287669,17z/data=!4m8!4m7!1m0!1m5!1m1!1s0x39eb1939433ddad7:0x7bde63fadb2efc24!2m2!1d85.3302641!2d27.7360022">Get Directions</a>',
        lat: 27.73480,
        long: 85.34028
    };

    

    var locations = [
      [broadway.info, broadway.lat, broadway.long, 0]

    ];

    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 13,
        center: new google.maps.LatLng(27.73480, 85.34028),
        mapTypeId: google.maps.MapTypeId.ROADMAP

    });

    var infowindow = new google.maps.InfoWindow({});

    var marker, i;

    for (i = 0; i < locations.length; i++) {
        marker = new google.maps.Marker({
            position: new google.maps.LatLng(locations[i][1], locations[i][2]),
            map: map
        });

        google.maps.event.addListener(marker, 'click', (function (marker, i) {
            return function () {
                infowindow.setContent(locations[i][0]);
                infowindow.open(map, marker);
            }
        })(marker, i));
    }
}
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC_blMLO4YnhnrLFVkYU2k25jQSEDS4m8Y&callback=initMap"
    async defer></script>
    

       
      
    </body>
</html>

