<?php $__env->startSection('breadcrumb','Member List'); ?>
<?php $__env->startSection('content'); ?>

<div class="card-body ">
  <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-6">
      <div class="btn-group">
        <a href="<?php echo e(route('member.create')); ?>" class="btn btn-info" role="button"><i class="fa fa-plus" aria-hidden="true"></i> Add New</a>
      </div>
    </div>

    <table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle" id="example4">
      <thead>

        <tr>
          <th>S.N.</th>
          <th></th>
          <th>Name</th>
          <th>Post</th>
          
          <th>About</th> 
          <th>Action</th>                               
        </tr>
      </thead>
      
      <tbody>
        <?php if(count($members) > 0): ?>
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
         <td><?php echo e(++$key); ?></td>
         <td class="patient-img">
           <img src="<?php echo e($member->photo); ?>" alt="" class="img img-circle">
         </td>
         <td><?php echo e($member->name); ?></td>
         <td><?php echo e($member->post); ?></td>                               
         <td><?php echo substr($member->about,0,100); ?></td>
         <td style="width: 100px;">
          <div style="float: left;">
            <a href='<?php echo e(route('member.edit',$member->id)); ?>'>
              <button class="btn btn-primary btn-xs">
                <i class="fa fa-edit"></i>
              </button>
            </a>
          </div>
          <div style="float: right;">
            <?php echo Form::open(['method'=>'DELETE','action'=>['TeamMemberController@destroy',$member->id]]); ?>

            <?php echo Form::button('<i class="fa fa-trash"></i>',['type'=>'submit','class'=>'btn btn-danger btn-xs','return onClick'=>'confirm("Are you sure to delete?")']); ?>

            <?php echo Form::close(); ?>

          </div>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <?php else: ?>
    <tr>
      <td colspan="100%"><h4>Member Table is Empty.</h4></td>
    </tr>
    <?php endif; ?>
    
    
    
  </table>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>