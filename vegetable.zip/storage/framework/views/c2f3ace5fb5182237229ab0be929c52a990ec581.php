<div class="slide">
	<div class="slideshow owl-carousel">
		<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="item">
			<img src="<?php echo e($slider->image); ?>" alt="banner" title="banner" class="img-responsive"/>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
	</div>
</div>
