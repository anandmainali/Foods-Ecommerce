<?php $__env->startSection('breadcrumb','Comment List'); ?>
<?php $__env->startSection('content'); ?>

          <div class="card-body ">
            
            <table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle" id="example4">
              <thead>
                <tr>
                  <th>S.N.</th>
                  <th> Name </th>                                                
                  <th> Email </th>
                  <th> Mobile </th>
                  <th> Message </th>                                                
                  <th> Action </th>
                </tr>
              </thead>
              <?php if(count($comments) > 0): ?>
              <tbody>
               
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="odd gradeX">
                  <td><?php echo e(++$key); ?></td>
                  <td><?php echo e($comment->name); ?></td>
                  <td><?php echo e($comment->email); ?></td>
                  <td><?php echo e($comment->mobile); ?></td>
                  
                  <td><?php echo e($comment->message); ?></td>
                  <td style="width: 60px;">
                    <?php echo Form::open(['method'=>'DELETE','action'=>['CommentController@destroy',$comment->id]]); ?>

                    <?php echo Form::button('<i class="fa fa-trash"></i>',['type'=>'submit','class'=>'btn btn-danger btn-xs','return onClick'=>'confirm("Are you sure to delete?")']); ?>

                    <?php echo Form::close(); ?>

                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <?php else: ?>
              
              <tr>
               <td colspan="100%"><h4>Comment Table is Empty.</h4></td>
             </tr>
             <?php endif; ?>
           </table>
         </div>
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>