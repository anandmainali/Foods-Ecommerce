 <!-- bootstrap carousel -->

    <?php $__env->startSection('content'); ?> 
        <div class="custom-breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Gallery</h2>
                    </div>
                </div>
            </div>
        </div><!--breadcrumb-->
        <div class="divide70"></div>

        <div class="container">           

          <div class="row">


              <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-md-6">
                      <?php if(count($album->image) > 0): ?>
                      <br><br>
                <h3><?php echo e($album->name); ?></h3><br>
                    <?php endif; ?>
                      <a href="<?php echo e(route('imageCollection',$album->id)); ?>">
                          <?php if(count($album->image) > 0): ?>
                          <img src="<?php echo e($album->image->first()->image); ?>" alt="" height="180px" width="250px">
                              <?php endif; ?>
                      </a>

                  </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


          </div>
        <!-- /.row -->

  <div class="divide80"></div>
        <?php echo $__env->make('layouts.includes.appointment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    

         <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>