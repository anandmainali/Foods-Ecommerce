    
    <?php $__env->startSection('breadcrumb','Profile'); ?>
    <?php $__env->startSection('content'); ?>
    <div class="card-body">  
        <div class="row">
            <div class="col-md-12">
                <!-- BEGIN PROFILE SIDEBAR -->
                <div class="profile-sidebar">
                    <div class="card card-topline-red">
                        <div class="card-body no-padding height-9">
                            <div class="row">
                                <div class="profile-userpic">
                                    <?php if(Auth::user()->image): ?>
                                    <img src="<?php echo e(Auth::user()->image); ?>" class="img-responsive" alt="">
                                    <?php else: ?>
                                    <img src="\UserImage\default.png" class="img-responsive" alt="">
                                    <?php endif; ?>
                                     </div>
                                </div>
                                <br>
                                <ul class="list-group list-group-unbordered">
                                    <li class="list-group-item">
                                        <b>Username</b> <a class="pull-right"><?php echo e(Auth::user()->uname); ?></a>
                                    </li>
                                    <li class="list-group-item">
                                        <b>Email</b> <a class="pull-right"><?php echo e(Auth::user()->email); ?></a>
                                    </li>
                                    <li class="list-group-item">
                                        <b>Role</b> <a class="pull-right"><?php echo e(ucfirst(Auth::user()->utype)); ?></a>
                                    </li>
                                </ul>
                                <!-- END SIDEBAR USER TITLE -->

                            </div>
                        </div>

                    </div>
                    <!-- END BEGIN PROFILE SIDEBAR -->


                </div>
            </div>
            <!-- end page content -->

        </div>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>