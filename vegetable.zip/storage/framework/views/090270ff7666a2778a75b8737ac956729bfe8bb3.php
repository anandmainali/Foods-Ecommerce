<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper">
<div class="page-content"> 
                 <div id="page-wrapper">
            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header" align="center">
                            Photo List                         
                        </h1>
                        <?php if(session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                        <?php endif; ?>
                    
                        <a href="<?php echo e(route('slider.create')); ?>" class="btn btn-primary" role="button"><i class="fa fa-plus" aria-hidden="true"></i> Add Slider</a>
                        
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Image</th>                                                                        
                                    <th>Action</th>                               
                                </tr>
                            </thead>
                            
                                <tbody>
                                	<?php if(count($sliders) > 0): ?>
                                	<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>	
                                <td><?php echo e(++$key); ?></td>                               
                                <td><img src="<?php echo e($slider->image); ?>" height="100px" alt=""></td>
                                <td>
                                    <?php echo Form::open(['method'=>'DELETE','action'=>['SliderController@destroy',$slider->id]]); ?>

                                    <?php echo e(Form::button('<i class="fa fa-trash"></i> Delete', ['type' => 'submit', 'class' => 'btn btn-danger btn-sm','onClick'=>'return confirm("Are you sure to delete?")'])); ?>

                                    <?php echo Form::close(); ?>











<!-- 
                                    <form method="DELETE" action="<?php echo e(route('slider.destroy',$slider->id)); ?>">
                                        <?php echo e(csrf_field()); ?>

                                    
                                        <button class="btn btn-danger btn-sm"
                                                onclick="return confirm('Are you sure you want to delete?')">
                                            <i class="fa fa-trash" aria-hidden="true"></i> Delete
                                        </button>
                                   
                                    </form> -->
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                           
                           <?php else: ?>
                            <tr>
                                <td colspan="6"><h3>Slider is Empty.</h3></td>
                            </tr>
                      		<?php endif; ?>
                            


                            
                        </table>
                            
                    </div>
                </div>
            </div>
        </div>
        </div>
        </div>

        <?php $__env->stopSection(); ?>
                        
                        





                        

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>