<?php $__env->startSection('content'); ?>


                <div class="page-content-wrapper">
                <div class="page-content">

        <!-- Admin Content -->
            <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                   
                        <h1 class="page-header">
                            Disorders List                            
                        </h1>
                        <a href="<?php echo e(route('disorder.create')); ?>" class="btn btn-primary" role="button"><i class="fa fa-plus" aria-hidden="true"></i> Add Disorder</a>
                        
                        <hr>
                        
                        
                        <div class="col-md-12">
                             <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Disease Name</th>
                                    <th>About Disease</th> 
                                    <th>Action</th>                               
                                </tr>
                            </thead>
                           
                               
                            <tbody>
                                <?php if(count($disorders) > 0): ?>
                                <?php $__currentLoopData = $disorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$disorder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($disorder->name); ?></td>
                                <td><?php echo e($disorder->about); ?></td>
                                <td>
                                    <a href=''>
                                        <button class="btn btn-danger btn-sm"
                                                onclick="return confirm('Are you sure you want to delete?')">
                                            <i class="fa fa-trash"></i> Delete
                                        </button>
                                    </a>
                                    <a href=''>
                                        <button class="btn btn-primary btn-sm">
                                            <i class="fa fa-edit"></i> Edit
                                        </button>
                                    </a>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        <?php else: ?>
                        <tr>
                            <td colspan="100%"><h3>No disorders found.</h3></td>
                        </tr>
                        <?php endif; ?>
                        </table>
                          
                        </div>   
                        
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>