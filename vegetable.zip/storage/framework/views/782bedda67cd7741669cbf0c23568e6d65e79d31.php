
<!DOCTYPE html>
<html lang="en">

<head>
    
        
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Arthritis Care Center</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/marquee.css')); ?>" />
		<link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/example.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/owl.carousel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/owl.theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/flexslider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/magnific-popup.css')); ?>">    
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/front-style.css')); ?>">

   
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>


</head>

<body>
    <div class="top">
            <div class="row">
                   <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 ">
                        <ul class="list-inline">
                            <li><i class="fa fa-phone"> <?php echo e($info->phone); ?></i></li>
                        </ul>
                    </div>
                    <div class="col-sm-6">
                        <ul class="list-inline pull-right">                        
                            <li><i class="fa fa-envelope-o"></i> <?php echo e($info->email); ?></li>
                            
                        </ul>                        
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                </div>


    <div class="container">
    <div class="row">
          <div class="col-sm-2 logo"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/Images/logo/logo.png')); ?>" alt="Arthritis Care Center"></a></div>
          <div class="col-sm-10 banner"><img src="<?php echo e(asset('/Images/logo/acc.jpg')); ?>" alt="" class="img-responsive"></div>
    </div>
    </div>

    <!-- Navigation -->

<nav id="navigation" class="navbar navbar-inverse">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="<?php echo e(url('/')); ?>" class="<?php echo e(Request::is('/') ? 'active' : ''); ?>">Home</a></li>
                        <li><a href="<?php echo e(url('/disorder')); ?>" class="<?php echo e(Request::is('disorder') ? 'active' : ''); ?>">Disorder We Treat</a></li>
                        <li><a href="<?php echo e(url('/appointment')); ?>" class="<?php echo e(Request::is('appointment') ? 'active' : ''); ?>">Make an appointment</a></li>   
                        <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" class="<?php echo e(Request::is('about') ? 'active' : ''); ?>">About <span class="caret"></span></a>               
              <ul class="dropdown-menu" role="menu">
                <li><a href="<?php echo e(url('/about/doctor')); ?>">Find Dr. Arun Kumar Gupta</a></li>
                <li class="divider"></li>
                <li><a href="<?php echo e(url('/about/rheumatology')); ?>">What is a Rheumatologist?</a></li>
                <li class="divider"></li>
                <li><a href="<?php echo e(url('/about/arthritis')); ?>">What is a Arthritis?</a></li>
                <li class="divider"></li>
                <li><a href="<?php echo e(url('/about/team')); ?>">Meet Our Team</a></li>
                
                
              </ul>                
            </li>                      
                        
                        <li><a href="<?php echo e(url('/gallery')); ?>" class="<?php echo e(Request::is('gallery') ? 'active' : ''); ?>">Gallery</a></li>
                        <li><a href="<?php echo e(url('/contact')); ?>" class="<?php echo e(Request::is('contact') ? 'active' : ''); ?>">Contact us</a></li>
                       <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                            <li><a href="<?php echo e(url('/admin')); ?>">Admin</a></li>
                            <!--<li><a href="<?php echo e(url('/logout')); ?>">LogOut</a></li>-->
                           <?php endif; ?>
                    </ul>
                </div><!--/.nav-collapse -->
            </div><!--/.container-fluid -->
        </nav>
        <br>
            <?php echo $__env->yieldContent('content'); ?>

























<footer class="footer">
             <div class="divide40"></div>
             <div class="socials-colored col-md-12 center">
                <a href="https://www.facebook.com/ACC-NEPAL-150458155777727/" class="social-icon social-ico-dark social-ico-colored-facebook">
                    <i class="fa fa-facebook"></i>
                    <i class="fa fa-facebook"></i>
                </a>
               <a href="#" class="social-icon social-ico-dark social-ico-colored-twitter">
                    <i class="fa fa-twitter"></i>
                    <i class="fa fa-twitter"></i>
                </a>
                <a href="#" class="social-icon social-ico-dark social-ico-colored-google-plus">
                    <i class="fa fa-google-plus"></i>
                    <i class="fa fa-google-plus"></i>
                </a>
                <a href="#" class="social-icon social-ico-dark social-ico-colored-youtube">
                    <i class="fa fa-youtube-play"></i>
                    <i class="fa fa-youtube-play"></i>
                </a>
               <a href="#" class="social-icon social-ico-dark social-ico-colored-linkedin">
                    <i class="fa fa-linkedin"></i>
                    <i class="fa fa-linkedin"></i>
                </a>
            </div>
           <div class="footer-copyright">
                 <div class="container">
                    <span><!--Copyright &copy; 2017. -->All right reserved | Arthritis Care Center <br><a href="https://www.facebook.com/profile.php?id=100004046676332" target="_top"   style="color:#fcf8e3">Designed & Developed by <b>Anand Kumar Mainali</b></a></span>
                </div>
            </div>
              
        </footer>
        <script src="<?php echo e(asset('bootstrap/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/frontend/jquery-migrate.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/frontend/jquery.flexslider-min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/frontend/jquery.stellar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/frontend/jquery.magnific-popup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/frontend/wow.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/frontend/custom.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/frontend/jquery.tickerNews.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('bootstrap/js/frontend/marquee.js')); ?>"></script>

       <script>
  $('#view_more').on('click', function () {
    var $btn = $(this).button('loading')
    // business logic...
    $btn.button('reset')
  })
</script>

       <!--gmap js-->

        <script>
      var map;
      function initMap() {
    
    var broadway = {
        info: '<strong>Arthritis Care Center</strong><br>\
                    Birgunj 44300<br>\
                    <a href="https://www.google.com.np/maps/place/Arthritis+Care+Centre/@27.0154474,84.8794182,21z/data=!4m5!3m4!1s0x39935440ce606785:0x3a9b755be8184bbb!8m2!3d27.0155464!4d84.8794384?hl=en">Get Directions</a>',
        lat: 27.015561,
        long: 84.879437
    };

    

    var locations = [
      [broadway.info, broadway.lat, broadway.long, 0]

    ];

    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 13,
        center: new google.maps.LatLng(27.015561, 84.879437),
        mapTypeId: google.maps.MapTypeId.ROADMAP

    });

    var infowindow = new google.maps.InfoWindow({});

    var marker, i;

    for (i = 0; i < locations.length; i++) {
        marker = new google.maps.Marker({
            position: new google.maps.LatLng(locations[i][1], locations[i][2]),
            map: map
        });

        google.maps.event.addListener(marker, 'click', (function (marker, i) {
            return function () {
                infowindow.setContent(locations[i][0]);
                infowindow.open(map, marker);
            }
        })(marker, i));
    }
}
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC_blMLO4YnhnrLFVkYU2k25jQSEDS4m8Y&callback=initMap"
    async defer></script>
    
    <script>
			$(function (){

				$('.simple-marquee-container').SimpleMarquee();
				
			});

		</script>
    

       
      
    </body>
</html>

