<?php $__env->startSection('breadcrumb','Add Testimonial'); ?>
<?php $__env->startSection('content'); ?>

<div class="card-body ">
 <div class="row">

    <?php echo Form::open(['method'=>'POST','action'=>'HappyCustomerController@store','files'=>true]); ?>

    <div class="col-md-12">
        <div class="form-group">
            <?php echo Form::label('name','Name'); ?>

            <?php echo Form::text('name',null,['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('post','Post'); ?>

            <?php echo Form::text('post',null,['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('photo','Photo'); ?>

            <?php echo Form::file('photo',['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('Comment','Description'); ?>

            <?php echo Form::textarea('about',null,['class'=>'form-control','id'=>'about']); ?>

        </div>

        <div class="form-group">                        
            <?php echo Form::button('<i class="fa fa-paper-plane"></i>Submit',['type'=>'submit','class'=>'btn btn-primary pull-right']); ?>

        </div>
        <a type="cancel" href="<?php echo e(route('customer.index')); ?>" class="btn btn-default pull-right">Cancel</a>
    </div>

    <?php echo Form::close(); ?>


</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>