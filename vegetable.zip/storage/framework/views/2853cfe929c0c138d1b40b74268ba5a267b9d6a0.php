

<?php $__env->startSection('content'); ?>

    <div class="page-content-wrapper">
        <div class="page-content">
            <div class="container-fluid">
                <div class="content">
                    <div class="row">
                        <div class="col-md-12">
                            <h1><i class="fa fa-edit"></i> Update Profile</h1>
                            <hr>
                            <?php if(session()->has('success')): ?>
                            <div class="alert alert-success">
                                <i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo e(session()->get('success')); ?>

                            </div>
                            <?php endif; ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <img  style="margin-top: 20px"  src="<?php echo e(Auth::user()->image); ?>" class="img-responsive thumbnail"  alt="">
                            </div>
                            <div class="col-md-7">
                                <?php echo Form::model(Auth::user(),['method'=>'PATCH','action'=>['AdminController@updateUser',Auth::user()->id],'files'=>true]); ?>

                                
                                        <div class="form-group">
                                            <?php echo Form::label('uname','Username'); ?>

                                            <?php echo Form::text('uname',null,['class'=>'form-control']); ?>

                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('email','Email'); ?>

                                            <?php echo Form::email('email',null,['class'=>'form-control']); ?>

                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('image','Photo'); ?>

                                            <?php echo Form::file('image',['class'=>'form-control']); ?>

                                        </div>                               
                                
                                        <div class="form-group">                        
                                            <?php echo Form::submit('Update User',['class'=>'btn btn-primary pull-right']); ?>

                                        </div>
                                
                                
                                <?php echo Form::close(); ?> 
                                
                               
                            </div>

                            <div class="col-md-12">
                                <h1><i class="fa fa-lock"></i> Update Password</h1>
                                <hr>
                                <?php if(session()->has('error')): ?>
                            <div class="alert alert-danger">
                                <i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo e(session()->get('error')); ?>

                            </div>
                            <?php endif; ?>
                                <?php echo Form::open(['method'=>'POST','action'=>['AdminController@updatePassword',Auth::user()->id]]); ?> 
                                <!-- <form method="POST" action="<?php echo e(route('updatePassword',Auth::user()->id)); ?>" >
                                    <?php echo e(csrf_field()); ?> -->
                                        <div class="form-group">
                                            <?php echo Form::label('oldPassword','Old Password'); ?>

                                            <?php echo Form::password('oldPassword',['class'=>'form-control']); ?>

                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('newPassword','New Password'); ?>

                                            <?php echo Form::password('newPassword',['class'=>'form-control']); ?>

                                        </div>

                                        <div class="form-group">
                                            <?php echo Form::label('confirmPassword','Confirm Password'); ?>

                                            <?php echo Form::password('confirmPassword',['class'=>'form-control']); ?>

                                        </div>

                                        <div class="form-group">                        
                                            <?php echo Form::submit('Update Password',['class'=>'btn btn-primary pull-right']); ?>

                                        </div>
                                
                                
                                <?php echo Form::close(); ?> 
                                
                            </div>





                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>