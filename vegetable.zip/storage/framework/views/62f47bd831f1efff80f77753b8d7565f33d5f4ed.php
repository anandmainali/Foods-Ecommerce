<?php $__env->startSection('body'); ?>

    <?php echo $__env->make('project.include.bread-crumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- register start here -->
    <div class="register">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3 col-sm-offset-3 box">
                    <div class="commontop text-left">
                        <h4>
                            Sign in
                            <i class="icon_star_alt"></i>
                            <i class="icon_star_alt"></i>
                            <i class="icon_star_alt"></i>
                        </h4>
                    </div>
                    <p>Hello, Welcome to your account</p>
                   <form class="form-signin" method="post" action="<?php echo e(route('login')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>"> 
                                <label>Email Address *</label>                           
                                <input id="email" type="email" placeholder="Email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>                           
                        </div>

             <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">   
             <label>password *</label>                      
                                <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>                            
                        </div>                    
            <div class="form-group">
                            
                                <button type="submit" class="btn btn-primary">
                                    Login
                                </button>
                                <button class="btn btn-primary pull-right" type="button" onclick="location.href='<?php echo e(route('signup')); ?>'">Register <i class="fa fa-arrow-right"></i></button>
                            </div>           

        </form>
                </div>
            </div>
        </div>
    </div>
    <!-- register end here -->


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('project.pages.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>