<div class="container">
	<div class="row">
		<div class="col-md-12 col-sm-12 col-lg-12 col-xs-12 commontop text-center">
			<p>Fresh Foods</p>
			<h4>
				<i class="icon_star_alt"></i>
				<i class="icon_star_alt"></i>
				<i class="icon_star_alt"></i>
				Our products
				<i class="icon_star_alt"></i>
				<i class="icon_star_alt"></i>
				<i class="icon_star_alt"></i>
			</h4>
		</div>
		<div class="col-md-12 col-sm-12 col-lg-12 col-xs-12">
			<ul class="nav nav-tabs list-inline">
				<li class="active">
					<a href="#all" data-toggle="tab" aria-expanded="true">Organic <span>All</span></a>
				</li>
				
			</ul>
			<div  class="tab-content">
				<div class="tab-pane active" id="all">
					
					<div class="row">
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
							<div class="product-thumb">
								<div class="image">
									<a href="<?php echo e(route('shop_detail',$product->id)); ?>">
										<img src="<?php echo e($product->image); ?>" alt="image" height="180" title="image" class="img-responsive" />
									</a>
									 <div class="onhover onhover9"> 
										<div class="list-unstyled">
										<?php if(auth()->check()): ?>										
												<form action="<?php echo e(route('wishlist.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" />
                                            <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>" />         
                                            <button type="submit"><i class="icon_heart"></i></button>	
                                        </form>
                                        <?php endif; ?>
											<form action="<?php echo e(route('cart.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                                            <input type="hidden" name="name" value="<?php echo e($product->name); ?>" />
                                            <input type="hidden" name="image" value="<?php echo e($product->image); ?>" />
                                            <input type="hidden" name="newprice" value="<?php echo e($product->newprice); ?>" />
                                            <input type="hidden" name="qty" value="1" />
                                            <button type="submit"><i class="icon_cart"></i></button>	
                                        </form>											
										</div>
									 </div>
								</div>
								<div class="caption text-center">
									<h4><a href="<?php echo e(route('shop_detail',$product->id)); ?>">Organic <span><?php echo e($product->name); ?></span></a></h4>
									<p class="price"><?php if($product->oldprice): ?><strike>Rs.<?php echo e($product->oldprice); ?></strike><?php endif; ?> Rs. <?php echo e($product->newprice); ?></p>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
				<div class="tab-pane" id="vegetables">
					<div class="row">
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
							<div class="product-thumb">
								<div class="image">
									<a href="<?php echo e(route('shop_detail',$product->id)); ?>">
										<img src="<?php echo e($product->image); ?>" alt="image" height="180" title="image" class="img-responsive" />
									</a>
									 <div class="onhover onhover9"> 
										<div class="list-unstyled">
											<?php if(auth()->check()): ?>
										<form action="<?php echo e(route('wishlist.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                                            <input type="hidden" name="name" value="<?php echo e(auth()->user()->id); ?>" />         
                                            <button type="submit"><i class="icon_heart"></i></button>	
                                        </form>										
											<?php else: ?>
												<a href="<?php echo e(route('wishlist.store')); ?>" type="button"><i class="icon_heart"></i></a>
											<?php endif; ?>	
											<form action="<?php echo e(route('cart.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                                            <input type="hidden" name="name" value="<?php echo e($product->name); ?>" />
                                            <input type="hidden" name="image" value="<?php echo e($product->image); ?>" />
                                            <input type="hidden" name="newprice" value="<?php echo e($product->newprice); ?>" />
                                            <input type="hidden" name="qty" value="1" />
                                            <button type="submit"><i class="icon_cart"></i></button>	
                                        </form>											
										</div>
									 </div>
								</div>
								<div class="caption text-center">
									<h4><a href="<?php echo e(route('shop_detail',$product->id)); ?>">Organic <span><?php echo e($product->name); ?></span></a></h4>
									<p class="price"><?php if($product->oldprice): ?><strike>Rs.<?php echo e($product->oldprice); ?></strike><?php endif; ?> Rs. <?php echo e($product->newprice); ?></p>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</div>
				</div>
				<div class="tab-pane" id="fruits">
					<div class="row">
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
							<div class="product-thumb">
								<div class="image">
									<a href="<?php echo e(route('shop_detail',$product->id)); ?>">
										<img src="<?php echo e($product->image); ?>" alt="image" height="180" title="image" class="img-responsive" />
									</a>
									 <div class="onhover onhover9"> 
										<div class="list-unstyled">										
												<button type="button"><i class="icon_heart"></i></button>
											<form action="<?php echo e(route('cart.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                                            <input type="hidden" name="name" value="<?php echo e($product->name); ?>" />
                                            <input type="hidden" name="image" value="<?php echo e($product->image); ?>" />
                                            <input type="hidden" name="newprice" value="<?php echo e($product->newprice); ?>" />
                                            <input type="hidden" name="qty" value="1" />
                                            <button type="submit"><i class="icon_cart"></i></button>	
                                        </form>											
										</div>
									 </div>
								</div>
								<div class="caption text-center">
									<h4><a href="<?php echo e(route('shop_detail',$product->id)); ?>">Organic <span><?php echo e($product->name); ?></span></a></h4>
									<p class="price"><?php if($product->oldprice): ?><strike>Rs.<?php echo e($product->oldprice); ?></strike><?php endif; ?> Rs. <?php echo e($product->newprice); ?></p>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
				<div class="tab-pane" id="meats">
					<div class="row">
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
							<div class="product-thumb">
								<div class="image">
									<a href="<?php echo e(route('shop_detail',$product->id)); ?>">
										<img src="<?php echo e($product->image); ?>" alt="image" height="180" title="image" class="img-responsive" />
									</a>
									 <div class="onhover onhover9"> 
										<div class="list-unstyled">										
												<button type="button"><i class="icon_heart"></i></button>
											<form action="<?php echo e(route('cart.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                                            <input type="hidden" name="name" value="<?php echo e($product->name); ?>" />
                                            <input type="hidden" name="image" value="<?php echo e($product->image); ?>" />
                                            <input type="hidden" name="newprice" value="<?php echo e($product->newprice); ?>" />
                                            <input type="hidden" name="qty" value="1" />
                                            <button type="submit"><i class="icon_cart"></i></button>	
                                        </form>											
										</div>
									 </div>
								</div>
								<div class="caption text-center">
									<h4><a href="<?php echo e(route('shop_detail',$product->id)); ?>">Organic <span><?php echo e($product->name); ?></span></a></h4>
									<p class="price"><?php if($product->oldprice): ?><strike>Rs.<?php echo e($product->oldprice); ?></strike><?php endif; ?> Rs. <?php echo e($product->newprice); ?></p>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
				<div class="tab-pane" id="foods">
					<div class="row">
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
							<div class="product-thumb">
								<div class="image">
									<a href="<?php echo e(route('shop_detail',$product->id)); ?>">
										<img src="<?php echo e($product->image); ?>" alt="image" height="180" title="image" class="img-responsive" />
									</a>
									 <div class="onhover onhover9"> 
										<div class="list-unstyled">										
												<button type="button"><i class="icon_heart"></i></button>
											<form action="<?php echo e(route('cart.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                                            <input type="hidden" name="name" value="<?php echo e($product->name); ?>" />
                                            <input type="hidden" name="image" value="<?php echo e($product->image); ?>" />
                                            <input type="hidden" name="newprice" value="<?php echo e($product->newprice); ?>" />
                                            <input type="hidden" name="qty" value="1" />
                                            <button type="submit"><i class="icon_cart"></i></button>	
                                        </form>											
										</div>
									 </div>
								</div>
								<div class="caption text-center">
									<h4><a href="<?php echo e(route('shop_detail',$product->id)); ?>">Organic <span><?php echo e($product->name); ?></span></a></h4>
									<p class="price"><?php if($product->oldprice): ?><strike>Rs.<?php echo e($product->oldprice); ?></strike><?php endif; ?> Rs. <?php echo e($product->newprice); ?></p>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
				<div class="tab-pane" id="juice">
					<div class="row">
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
							<div class="product-thumb">
								<div class="image">
									<a href="<?php echo e(route('shop_detail',$product->id)); ?>">
										<img src="<?php echo e($product->image); ?>" alt="image" height="180" title="image" class="img-responsive" />
									</a>
									 <div class="onhover onhover9"> 
										<div class="list-unstyled">										
												<button type="button"><i class="icon_heart"></i></button>
											<form action="<?php echo e(route('cart.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                                            <input type="hidden" name="name" value="<?php echo e($product->name); ?>" />
                                            <input type="hidden" name="image" value="<?php echo e($product->image); ?>" />
                                            <input type="hidden" name="newprice" value="<?php echo e($product->newprice); ?>" />
                                            <input type="hidden" name="qty" value="1" />
                                            <button type="submit"><i class="icon_cart"></i></button>	
                                        </form>											
										</div>
									 </div>
								</div>
								<div class="caption text-center">
									<h4><a href="<?php echo e(route('shop_detail',$product->id)); ?>">Organic <span><?php echo e($product->name); ?></span></a></h4>
									<p class="price"><?php if($product->oldprice): ?><strike>Rs.<?php echo e($product->oldprice); ?></strike><?php endif; ?> Rs. <?php echo e($product->newprice); ?></p>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
