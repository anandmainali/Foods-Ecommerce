<?php $__env->startSection('breadcrumb','Edit Category'); ?>
<?php $__env->startSection('content'); ?>
<div class="card-body ">
   <div class="row">
    <?php echo Form::model($category,['method'=>'PATCH','action'=>['CategoryController@update',$category->id]]); ?>

    <div class="col-md-12">
        <div class="form-group">
            <?php echo Form::label('name','Name'); ?>

            <?php echo Form::text('name',null,['class'=>'form-control']); ?>

        </div>
        
        <div class="form-group">
            <?php echo Form::button('<i class="fa fa-paper-plane"></i>Submit',['type'=>'submit','class'=>'btn btn-primary pull-right']); ?>

        </div>
        <a type="cancel" href="<?php echo e(route('category.index')); ?>" class="btn btn-default pull-right">Cancel</a>
    </div>
    
    <?php echo Form::close(); ?>

    

</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>