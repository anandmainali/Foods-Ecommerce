
<?php $__env->startSection('breadcrumb','Dashboard'); ?>
<?php $__env->startSection('content'); ?>

        <!-- start widget -->
        <div class="card-body">
        <div class="row">
            <div class="state-overview">
                <div class="col-lg-3 col-sm-6">
                    <div class="overview-panel blue">
                        <div class="symbol">
                            <i class="fa fa-shopping-cart usr-clr"></i>
                        </div>
                        <div class="value white">
                            <p class="sbold addr-font-h1" data-counter="counterup" data-value="<?php echo e(count($orders)); ?>">0</p>
                            <p>Orders</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="overview-panel grey">
                        <div class="symbol">
                            <i class="fa fa-shopping-basket"></i>
                        </div>
                        <div class="value white">
                            <p class="sbold addr-font-h1" data-counter="counterup" data-value="<?php echo e(count($products)); ?>">0</p>
                            <p>Products</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="overview-panel orange">
                        <div class="symbol">
                            <i class="fa fa-list-alt"></i>
                        </div>
                        <div class="value white">
                            <p class="sbold addr-font-h1" data-counter="counterup" data-value="<?php echo e(count($categories)); ?>">0</p>
                            <p>Categories</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="overview-panel green-bgcolor">
                        <div class="symbol">
                            <i class="fa fa-user"></i>
                        </div>
                        <div class="value white">
                            <p class="sbold addr-font-h1" data-counter="counterup" data-value="<?php echo e(count($users)); ?>">0</p>
                            <p>Users</p>
                        </div>
                    </div>
                </div>                       
                
            </div>
        </div>
        <!-- end widget -->
        
        
        
    </div>

<!-- end page content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>