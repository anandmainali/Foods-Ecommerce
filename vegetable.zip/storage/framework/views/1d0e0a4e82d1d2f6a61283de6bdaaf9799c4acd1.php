
 <!-- bootstrap carousel -->

    <?php $__env->startSection('content'); ?> 
<div class="custom-breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1>What is  Arthritis?</h1>
                    </div>
                </div>
            </div>
        </div><!--breadcrumb-->
        <div class="divide70"></div>

            <div class="container disorder">
                <div class="row">
                    <div class="col-md-11 col-md-offset-0.5">
                    Arthritis is a term often used to mean any disorder that affects joints. Symptoms generally include joint pain and stiffness. Other symptoms may include redness, warmth, swelling, and decreased range of motion of the affected joints. In some types other organs are also affected. Onset can be gradual or sudden. <br><br>

There are over 100 types of arthritis. The most common forms are osteoarthritis (degenerative joint disease) and rheumatoid arthritis. Osteoarthritis usually occurs with age and affects the fingers, knees, and hips. Rheumatoid arthritis is an autoimmune disorder that often affects the hands and feet. Other types include gout, lupus, fibromyalgia, and septic arthritis. They are all types of rheumatic disease. <br><br>

Treatment may include resting the joint and alternating between applying ice and heat. Weight loss and exercise may also be useful. Pain medications such as ibuprofen and paracetamol (acetaminophen) may be used. In some a joint replacement may be useful. <br><br>

Osteoarthritis affects more than 3.8% of people while rheumatoid arthritis affects about 0.24% of people. Gout affects about 1 to 2% of the Western population at some point in their lives. In Australia about 15% of people are affected, while in the United States more than 20% have a type of arthritis. Overall the disease becomes more common with age. Arthritis is a common reason that people miss work and can result in a decreased quality of life. The term is from Greek arthro- meaning joint and -its meaning inflammation. <br><br>


<h3> Classification</h3>
There are several diseases where joint pain is primary, and is considered the main feature. Generally when a person has "arthritis" it means that they have one of these diseases, which include: <br>
<ul>
<li> Osteoarthritis </li>
<li>Rheumatoid arthritis</li>
<li>Gout and pseudo-gout</li>
<li>Septic arthritis</li>
<li>Ankylosing spondylitis</li>
<li>Juvenile idiopathic arthritis</li>
<li>Still's disease</li><br><br>

</ul>


<h3> Signs and symptoms </h3>

Pain, which can vary in severity, is a common symptom in virtually all types of arthritis. Other symptoms include swelling, joint stiffness and aching around the joint(s). Arthritic disorders like lupus and rheumatoid arthritis can affect other organs in the body, leading to a variety of symptoms. Symptoms may include: <br><br>
<ul>
<li>Inability to use the hand or walk</li>
<li>Stiffness, which may be worse in the morning, or after use</li>
<li>Malaise and fatigue</li>
<li>Weight loss</li>
<li>Poor sleep</li>
<li>Muscle aches and pains</li>
<li>Tenderness</li>
<li>Difficulty moving the joint</li>
</ul>
It is common in advanced arthritis for significant secondary changes to occur. For example, arthritic symptoms might make it difficult for a person to move around and/or exercise, which can lead to secondary effects, such as:<br>
<ul>
<li>Muscle weakness</li>
<li>Loss of flexibility</li>
<li>Decreased aerobic fitness</li>
</ul>

These changes, in addition to the primary symptoms, can have a huge impact on quality of life.<br><br><br><br>
            </div>
            </div>
            </div>
        </section>
        <!--know more section end-->

        <?php echo $__env->make('layouts.includes.appointment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    

         <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>