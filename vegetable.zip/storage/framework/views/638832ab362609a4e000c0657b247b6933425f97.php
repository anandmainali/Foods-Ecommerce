<div class="ads-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 text-center">
                        <h3>We offer full medical exam !!!</h3>
                    </div>
                    <div class="col-md-4 text-center">
                        <a href="<?php echo e(url('/appointment')); ?>" class="btn btn-white-border btn-lg">Make an appointment</a>
                    </div>
                </div>
            </div>
        </div><br><br>
