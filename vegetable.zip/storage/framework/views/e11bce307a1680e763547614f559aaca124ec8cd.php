

<?php $__env->startSection('content'); ?>



    <!-- start page content -->
    <div class="page-content-wrapper">
        <div class="page-content">
            <div class="page-bar">
                <div class="page-title-breadcrumb">
                    <div class=" pull-left">
                        <div class="page-title">Photos List</div>
                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success"><i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo e(session()->get('success')); ?></div>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
            <a href="<?php echo e(route('image.create')); ?>" class="btn btn-primary" role="button"><i class="fa fa-plus" aria-hidden="true"></i> Add Photo</a>
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-topline-red">
                        <div class="card-head">
                            <header></header>
                            <div class="tools">
                                <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                                <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                                <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                            </div>
                        </div>
                        <div class="card-body ">

                            <table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle" id="example4">
                                <thead>

                                <tr>
                                    <th>Id</th>
                                    <th>Albums</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <?php if(count($photos) > 0): ?>
                                    <tbody>
                                    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td><?php echo e($photo->album->name); ?></td>
                                            <td>
                                                <img src="<?php echo e($photo->image); ?>" width="100" alt="">
                                            </td>
                                            <td>
                                                <?php echo Form::open(['method'=>'DELETE','action'=>['ImageController@destroy',$photo->id]]); ?>

                                                <?php echo e(Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-sm','onClick'=>'return confirm("Are you sure to delete?")'])); ?>

                                                <?php echo Form::close(); ?>


                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="100%"><h3>No photos found.</h3></td>
                                    </tr>
                                <?php endif; ?>
                            </table>
                            <div class="paginate pull-right">
                                <?php echo e($photos->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>












<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>