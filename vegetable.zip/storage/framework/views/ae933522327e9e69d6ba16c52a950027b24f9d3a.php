<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper">
<div class="page-content"> 
        <!-- Admin Content -->
            <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                   
                        <h1 class="page-header">
                            Branch List                            
                        </h1>
                        <a href="<?php echo e(route('branch.create')); ?>" class="btn btn-primary" role="button"><i class="fa fa-plus" aria-hidden="true"></i> Add Branch</a>
                        
                        <hr>
                        <?php if(session()->has('success')): ?>
                        <li class="alert alert-success"><?php echo e(session()->get('success')); ?></li>
                        <?php endif; ?>
                        
                        <div class="col-md-12">
                             <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>                                                                       
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Address</th>                            
                                    <th>Action</th>                                 
                                </tr>
                            </thead>
                                                           
                            <tbody>
                                <?php if(count($branches) > 0): ?>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($branch->email); ?></td>
                                <td><?php echo e($branch->phone); ?></td>
                                <td><?php echo e($branch->address); ?></td>
                                <td>
                                    <?php echo Form::open(['method'=>'DELETE','action'=>['BranchController@destroy',$branch->id]]); ?>

                                    <?php echo Form::button('<i class="fa fa-trash"></i> Delete',['type'=>'submit','class'=>'btn btn-danger','return onClick'=>'confirm("Are you sure to delete?")']); ?>

                                    <?php echo Form::close(); ?>

                                    <a href=''>
                                        <button class="btn btn-primary btn-sm">
                                            <i class="fa fa-edit"></i> Edit
                                        </button>
                                    </a>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>                        
                        <?php else: ?>
                        <tr>
                            <td colspan="100%"><h3>No branches found.</h3></td>
                        </tr>
                        <?php endif; ?>
                        </table>
                            
                        </div>   
                        
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>