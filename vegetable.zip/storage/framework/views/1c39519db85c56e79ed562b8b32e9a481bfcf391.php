<?php $__env->startSection('breadcrumb','Product List'); ?>
<?php $__env->startSection('content'); ?>

					<div class="card-body ">
						<div class="row">
							<div class="col-md-6 col-sm-6 col-xs-6">
								<div class="btn-group">
        <a href="<?php echo e(route('product.create')); ?>" class="btn btn-info" role="button"><i class="fa fa-plus" aria-hidden="true"></i> Add New</a>
      </div>
							</div>
							
						</div>
						<table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle" id="example4">
							<thead>
								<tr>
									<th>S.N.</th>
									<th>Image</th>
									<th> Category</th>
									<!-- <th> Subcategory</th> -->
									<th> Product Name </th>
									<th> Discount (%)</th>
									<th> Price (Rs.)</th>									
									<th>Featured</th>									
									<th> Action </th>
								</tr>
							</thead>
							
							<?php if(count($products) > 0): ?>
							<tbody>
								<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr class="odd gradeX">
									<td class="center"><?php echo e(++$key); ?></td>
									<td class="center"><img src="<?php echo e($product->image); ?>" alt="Product Image" height="50"></td>
									<td class="center"><?php echo e($product->category->name); ?></td>
									<!-- <td class="center"></td> -->
									<td class="center"><?php echo e($product->name); ?></td>
									<td class="center"><?php echo e($product->discount); ?></td>
									<td class="center"><?php echo e($product->newprice); ?></td>
									<?php if($product->featured === 1): ?>								
									<td class="center"><span class="label label-success">Yes</span></td>
									<?php else: ?>
									<td class="center"><span class="label label-danger">No</span></td>
									<?php endif; ?>									
									<td class="center" style="width: 100px;">
							          <div style="float: left;">
                        <a href='<?php echo e(route('product.edit',$product->id)); ?>'>
                            <button class="btn btn-primary btn-xs">
                                <i class="fa fa-edit"></i>
                            </button>
                        </a>
                    </div>
                    <div style="float: right;">
                        <?php echo Form::open(['method'=>'DELETE','action'=>['ProductController@destroy',$product->id]]); ?>

                        <?php echo Form::button('<i class="fa fa-trash"></i>',['type'=>'submit','class'=>'btn btn-danger btn-xs','return onClick'=>'confirm("Are you sure to delete?")']); ?>

                        <?php echo Form::close(); ?>

                    </div>
							        </td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
							</tbody>
							<?php else: ?>							
								<tr >
									<td colspan="100%"><h4>Product Table is Empty.</h4></td>
								</tr>
							<?php endif; ?>
						</table>                                    
					</div>
				
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>