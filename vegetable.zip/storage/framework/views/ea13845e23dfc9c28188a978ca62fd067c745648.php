<!-- bootstrap carousel -->

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.includes.carousel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="divide70"></div>
<div class="container">
    <div class="row center-title">
        <div class="col-md-12  clearfix text-center wow animated fadeInUp">
            <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h2><strong><?php echo e($info->name); ?></strong></h2>
            <div class="name">
                <p>
                    <?php echo html_entity_decode($info->about); ?>

                </p>
            </div>
            <!--                   -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <br><br>
    <div class="row">
        <div class="col-sm-6 col-md-3 margin30">
            <div class="service-box wow animated fadeIn" data-wow-delay="0.4s">
                <i class="fa fa-clock-o"></i>
                <h4>Make Appointment</h4>
                <p>Make a appointment with our doctors for treatment in time.</p>
                <div class="top-bar-right">
                    <a href="<?php echo e(route('appointment')); ?>" class="appointment">View Details...</a><br>
                </div>
                <br>
            </div>
        </div><!--service column-->

        <div class="col-sm-6 col-md-3 margin30">
            <div class="service-box wow animated fadeIn" data-wow-delay="0.2s">
                <i class="fa fa-user"></i>
                <h4>Team Members</h4>
                <p>Meet our members of Arthritis care center. </p>
                <div class="top-bar-right">
                    <a href="<?php echo e(route('team')); ?>" class="appointment">View Details...</a><br>
                </div>
                <br>
            </div>
        </div><!--service column-->

        <div class="col-sm-6 col-md-3 margin30">
            <div class="service-box wow animated fadeIn" data-wow-delay="0.3s">
                <i class="fa fa-picture-o"></i>
                <h4>Our Events</h4>
                <p>View events carried by Arthritis care center in different places.</p>
                <div class="top-bar-right">
                    <a href="<?php echo e(route('gallery')); ?>" class="appointment">View Details...</a><br>
                </div>
                <br>
            </div>
        </div><!--service column-->
        <div class="col-sm-6 col-md-3 margin30">
            <div class="service-box wow animated fadeIn" data-wow-delay="0.1s">
                <i class="glyphicon glyphicon-earphone"></i>
                <h4>contact us </h4>
                <p>Contact us to know more about our services.</p>
                <div class="top-bar-right">
                    <a href="<?php echo e(route('contact')); ?>" class="appointment">View Details...</a><br>
                </div>
                <br>
            </div>
        </div><!--service column-->

    </div>
</div>

<div class="divide20"></div>

    <?php if(count($branches) > 0): ?>

    <div class="team-section">
        <div class="container">
            <div class="center-title">
                <i class="fa fa-building-o fa-lg"></i>
                <h2>Our <strong> Branches</strong></h2>
            </div>
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2 text-center">
                    <div class="testi-slides">
                        <ul class="slides">

                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <strong>Location:</strong> <?php echo e($branch->address); ?><br>
                                <strong>Contact:</strong> <?php echo e($branch->phone); ?><br>
                                <strong>Email :</strong> <?php echo e($branch->email); ?><br>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </div><!--team section end-->
    <?php endif; ?>
    
        <?php if(count($customers) > 0): ?>
        <div class="team-section">
        <div class="container">
            <div class="center-title">
                <i class="fa fa-volume-up fa-lg"></i>
            <h2>What people say<strong> about us</strong></h2>
            </div>
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2 text-center">
                    <div class="testi-slides">
                        <ul class="slides">
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li align="center">
                                <?php if($customer->photo === NULL): ?>
                                <img src="/Images/logo/profile.png" alt="uraj mainali" height="250px" width="250px" class="img-circle">
                        
                        <?php else: ?>
                        <img src="/Images/Customers/<?php echo e($customer->photo); ?>" alt="" height="250px" width="250px" class="img-circle">
                        <?php endif; ?>
                        <div>
                            <b><?php echo e($customer->name); ?></b><br>
                            <i><?php echo e($customer->post); ?></i>
                            <p>
                                <?php echo $customer->about; ?>

                            </p>
                        </div>
                    </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </div><!--team section end-->
    <?php endif; ?>
<!--<section class="testimonials">
    <div class="container">
        <div class="center-title">
            <i class="fa fa-volume-up fa-lg"></i>
            <h2>What people say<strong> about us</strong></h2>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="col-md-4">
                    <li align="center">
                        <img src="<?php echo e(asset('Images/medical/1.jpg')); ?>" alt="" height="250px" width="250px" class="img-circle">
                        <div>
                            <b>Anand Kumar Mainali</b><br>
                            <i>Software developer</i>
                            <p>
                                From start to finish, the care my brother received was outstanding. All staff were professional and answered all questions and worries with great confidence and care, which made my brother's time in hospital go very smoothly.
                            </p>
                        </div>
                    </li>
                </div>
                <div class="col-md-4">
                    <li align="center">
                        <img src="<?php echo e(asset('Images/medical/2.jpg')); ?>" alt="" height="250px" width="250px" class="img-circle">
                        <div>
                            <b>Munna Mustaq</b><br>
                            <i>Student</i>

                            <p>
                                A brilliant hospital, felt so cared for after being transferred from another hospital due to a medical problem. It restored my faith in the medical profession.
                            </p>
                        </div>
                    </li>
                </div>
                <div class="col-md-4">
                    <li align="center">
                        <img src="<?php echo e(asset('Images/medical/3.jpg')); ?>" alt="" height="250px" width="250px" class="img-circle">
                        <div>
                            <b>Subash Khatri</b><br>
                            <i>Businessman</i>

                            <p>
                                I will say that I have been to a lot of care centers and Arthritis Care Center is number one for me. The service the doctors and nurses give me was excellent. Thank you staff.
                            </p>
                        </div>
                    </li>
                </div>-->
                </ul>
            </div>

        </div>
</section>
    <?php echo $__env->make('layouts.includes.appointment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.home-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>