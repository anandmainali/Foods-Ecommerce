 <!-- bootstrap carousel -->
    <?php $__env->startSection('content'); ?> 
<div class="custom-breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Disorders List</h2>
                    </div>
                </div>
            </div>
        </div><!--breadcrumb-->
        <div class="divide70"></div>

            <div class="container disorder">
                <div class="row">
                    
                    <div class="col-sm-10 margin30">
                        

                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

      <?php $__currentLoopData = $disorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$disorder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>               
    <div class="panel panel-primary collapse-colored-col">
    <div class="panel-heading heading" role="tab" id="<?php echo e($disorder->name); ?>">
      <h4 class="panel-title">
        <a class="collapsed paneltitle" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($disorder->id); ?>" aria-expanded="false" aria-controls="<?php echo e($disorder->id); ?>">
            <?php echo e($disorder->name); ?>

        </a>
        
      </h4>

    </div>
    <div id="collapse<?php echo e($disorder->id); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="<?php echo e($disorder->name); ?>">
      <div class="panel-body">
        <p><?php echo mb_substr(html_entity_decode($disorder->about),0,250)."..."; ?></p>
        <div class="col-md-4 col-md-offset-4">
        <button type="button" name="view_more" class="btn btn-primary" data-toggle="modal" data-target="#<?php echo e($key); ?>">View More...</button>
  

        </div>

      </div>

    </div>

  </div><!-- /.panel-group -->

             <!-- Modal -->
            <div class="modal fade" id="<?= $key ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><?php echo e($disorder->name); ?></h4>
      </div>
      <div class="modal-body">
        <?php echo html_entity_decode($disorder->about); ?>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 

                        
                    </div>
                </div>
            </div>
            </div>


        </section>
        <!--know more section end-->
        <?php echo $__env->make('layouts.includes.appointment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    

         <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.home-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>