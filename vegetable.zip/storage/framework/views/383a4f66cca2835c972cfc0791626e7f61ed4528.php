 <!-- bootstrap carousel -->

    <?php $__env->startSection('content'); ?> 
        <div class="custom-breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Gallery</h2>
                    </div>
                </div>
            </div>
        </div><!--breadcrumb-->
        <div class="divide70"></div>

        <div class="container">           

            <div class="row">
                
            <!-- Blog Entries Column -->
             
                <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>             
                    <div class="col-sm-6 col-md-3">
            <div class="col-md-12 img-with-text">
               
               
                        <div class="gallery thumbnail ">                   
                            
                            <img src="<?php echo e($photo->image); ?>" alt="gallery-img" class="home_page_photo img-responsive">
                            
                            <div class="gallery-overlay">
                            <p><a href="<?php echo e($photo->image); ?>" class="show-image"><i class="glyphicon glyphicon-eye-open"></i></a></p>
                        
                        </div>
                                       
                       

                </div>
                 <p><?php echo e($photo->title); ?></p>
               
                </div> 
            </div>        
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- /.row -->

  <div class="divide80"></div>
        <?php echo $__env->make('layouts.includes.appointment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    

         <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>