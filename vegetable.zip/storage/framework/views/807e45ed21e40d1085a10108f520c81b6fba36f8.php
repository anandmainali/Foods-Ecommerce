<?php $__env->startSection('content'); ?>



                <div class="page-content-wrapper">
                <div class="page-content">
                
        <div id="page-wrapper">
            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header" >
                            Member List                         
                        </h1>
                        <a href="<?php echo e(route('member.create')); ?>" class="btn btn-primary" role="button"><i class="fa fa-plus" aria-hidden="true"></i> Add Member</a>
                       
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Member Name</th>
                                    <th>Post</th>
                                    <th>Photo</th>
                                    <th>About Member</th> 
                                    <th>Action</th>                               
                                </tr>
                            </thead>
                           
                                <tbody>
                                    <?php if(count($members) > 0): ?>
                                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                               <td><?php echo e(++$key); ?></td>
                               <td><?php echo e($member->name); ?></td>
                               <td><?php echo e($member->post); ?></td>
                               <td>
                                   <img src="" alt="" width="60">
                               </td>
                               <td><?php echo e($member->about); ?></td>
                               <td>
                                    <a href=''>
                                        <button class="btn btn-danger btn-sm"
                                                onclick="return confirm('Are you sure you want to delete?')">
                                            <i class="fa fa-trash"></i> Delete
                                        </button>
                                    </a>
                                    <a href=''>
                                        <button class="btn btn-primary btn-sm">
                                            <i class="fa fa-edit"></i> Edit
                                        </button>
                                    </a>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                            <?php else: ?>
                            <tr>
                                <td colspan="8"><h3>No members found.</h3></td>
                            </tr>
                            <?php endif; ?>
                            
                                
                            
                        </table>
                      
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

                   
                        





                        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>