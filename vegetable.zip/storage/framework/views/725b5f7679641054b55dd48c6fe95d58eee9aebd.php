
<!-- bootstrap carousel -->

<?php $__env->startSection('content'); ?>
    <!-- Page Content -->

    <div class="page-content-wrapper">
        <div class="page-content">
            <div class="page-bar">
                <div class="page-title-breadcrumb">
                    <div class=" pull-left">
                        <div class="page-title">Album</div>
                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success"><i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo e(session()->get('success')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

                    <div class="col-md-4">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php echo Form::open(['method'=>'POST','action'=>'AlbumsController@store','files'=>true ]); ?>


                            <div class="form-group">
                                <?php echo Form::label('name','Name'); ?>

                                <?php echo Form::text('name',null,['class'=>'form-control']); ?>

                            </div>


                            <div class="form-group">
                                <?php echo Form::submit('Create Album',['class'=>'btn btn-primary pull-right']); ?>

                            </div>


                            <?php echo Form::close(); ?>

                        </div>



                    <div class="col-md-6 col-md-offset-1">
                        <br>
                    <table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle" id="example4">
                        <thead>
                        <tr>
                            <th>S.N.</th>
                            <th>Album Name</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e(++$key); ?></td>
                        <td><?php echo e($album->name); ?></td>
                        <td>
                            <?php echo Form::open(['method'=>'DELETE','action'=>['AlbumsController@destroy',$album->id]]); ?>

                            <?php echo e(Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-sm','onClick'=>'return confirm("Are you sure to delete?")'])); ?>

                            <?php echo Form::close(); ?>


                        </td>
                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </div>








<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>