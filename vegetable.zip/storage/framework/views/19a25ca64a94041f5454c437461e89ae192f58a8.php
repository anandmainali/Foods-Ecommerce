
<div id="carousel-header" class="carousel slide" data-ride="carousel" data-interval="3000">  			
  
  				<!-- Wrapper for slides -->
  				<div class="carousel-inner" role="listbox">
             <!--<div class="item active"> 
                      <img src="<?php echo e(asset('/Images/Slider/Slider1.jpg')); ?>" alt="" class="img-responsive slider">              
            </div>   -->    

            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item <?php echo e($loop->first ? ' active' : ''); ?>"> 
              <div class="item-img-wrap">
                <img src="<?php echo e($slider->image); ?>" alt="" class="img-responsive slider">
                </div>                
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     

  				</div>
  			
            <!-- Controls --> 
                
                <a class="left carousel-control" href="#carousel-header" role="button" data-slide="prev">
                  <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#carousel-header" role="button" data-slide="next">
                  <span class="glyphicon glyphicon-chevron-right fa-lg" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
                </a>
            
			
			</div><br><br>
  
      <div class="TickerNews" id="T1">
        <p>Find <b>Dr. Arun Kumar Gupta</b> in following places,</p>
            <div class="ti_wrapper">

                <div class="ti_slide">
                    
                    <div class="ti_content btn btn-danger">
                      
                      <?php $__currentLoopData = $associates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$associate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="ti_news"><a href="<?php echo e(url('/about/doctor')); ?>" class=""><?php echo e(++$key.". ". $associate->name); ?> &emsp; </a></div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                
            </div>
        </div>
        <br><br>
            <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($info->notice != NULL): ?>
		<div class="content">
			<div class="simple-marquee-container">
				<div class="marquee-sibling">
					<h3 style="color:white;margin-top:10px">Notice:-</h3>
				</div>
				<div class="marquee">
					<ul class="marquee-content-items">
					    <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo $info->notice; ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</ul>
				</div>
			</div>
		</div>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
