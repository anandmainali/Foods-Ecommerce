 <!-- bootstrap carousel -->

    <?php $__env->startSection('content'); ?>
        <div class="col-sm-6 col-sm-offset-3">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success"><i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo e(session()->get('success')); ?></div>
                <?php endif; ?>
        </div>
        <div class="custom-breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Contact us</h2>                       
                    </div>
                </div>
            </div>
        </div><!--breadcrumb-->
        <div class="divide30"></div>
        
        <!--g map start-->
         <div id="map" ></div>
        <!--g map end-->
        <div class="divide70"></div>

        <div class="container">
            <div class="row">
              <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="contact-info">
                    <div class="col-md-4">
                    <div class="media">
                        <div class="media-left">
                            <i class="fa fa-home fa-lg" aria-hidden="true"></i>
                        </div>
                        <div class="media-body">
                            <p><?php echo e($info->address); ?></p>
                        </div>
                    </div>
                    </div><!--media-->
                    <div class="col-md-4">
                    <div class="media">
                        <div class="media-left">
                            <i class="fa fa-envelope-o fa-lg" aria-hidden="true"></i>
                        </div>
                        <div class="media-body">
                            <p><?php echo e($info->email); ?></p>
                        </div>
                    </div>
                    </div><!--media-->
                    <div class="col-md-4">
                       <div class="media">
                        <div class="media-left">
                            <i class="fa fa-phone fa-lg" aria-hidden="true"></i> 
                        </div>
                        <div class="media-body">
                            <p>+977 <?php echo e($info->phone); ?></p>
                        </div>
                    </div>
                    </div><!--media-->                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <!-- Contact Form -->
                <div class="col-md-12"> 
                  <!-- IMPORTANT: change the email address at the top of the mail/mail.php file to the email address that you want this form to send to -->
                  <form class="form-style clearfix" action="" method="POST" role="form">
                    <?php echo e(csrf_field()); ?>

                    <!-- Left Column -->
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <input type="text" class="text-field form-control required"  placeholder="Full Name" name="name" >
                        </div>
                        <div class="form-group">
                          <input type="email" class="text-field form-control required" placeholder="Email Address" name="email">
                        </div>
                        <div class="form-group">
                          <input type="tel" class="text-field form-control" placeholder="Contact Number" name="mobile">
                        </div>
                        
                      </div>
                    
                    <!-- END: Left Column --> 
                    
                    
                      <!-- Right Column -->
                      <div class="col-md-6">
                        <div class="form-group">
                          <textarea placeholder="Message..." class="form-control required" name="message"></textarea>
                        </div>
                        <div class="form-group">
                          <button type="submit" name="submit" class="btn btn-lg btn-outline-inverse  submit">Submit</button>
                        </div>
                        <div class="form-group"></div>
                      </div>
                      <!-- END: Right Column -->
                    </div>
                  </form>
                </div>
                <!-- END: Contact Form --> 
     
            </div>
        </div>
    <div class="divide30"></div>

  <?php echo $__env->make('layouts.includes.appointment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>