
<?php $__env->startSection('body'); ?>

<!-- bread-crumb start here -->
<div class="bread-crumb">
    <img src="<?php echo e(URL::to('project/images/top-banner.jpg')); ?>" class="img-responsive" alt="banner-top" title="banner-top">
    <div class="container">
        <div class="matter">
            <h2><span>Organic</span> Cart</h2>
            <ul class="list-inline">
                <li>
                    <a href="<?php echo e(route('index')); ?>">HOME</a>
                </li>
                <li>
                    <a>Cart</a>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- bread-crumb end here -->

<!-- checkout start here -->
<div class="mycart">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <form method="post" enctype="multipart/form-data">
                    <div class="table-responsive">
                        <table class="table listproducts">
                            <thead>
                                <tr>
                                    <td class="text-left">List Products</td>
                                    <td class="text-center">Price</td>
                                    <td class="text-center">Quantity(Kg)</td>
                                    <td class="text-center">Total</td>
                                    <td class="text-center">Delete</td>
                                </tr>
                            </thead>
                            <tbody>
                              <?php if(count(Cart::content())>0): ?>                                
                                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-left">
                                        <a href="<?php echo e(route('shop_detail',$product->id)); ?>"><img src="<?php echo e($product->model->image); ?>" class="img-responsive" alt="img" title="img" /></a>
                                        <div class="name"><a href="<?php echo e(route('shop_detail',$product->id)); ?>"><?php echo e($product->model->name); ?></a></div>
                                    </td>
                                    <td class="text-center" >Rs.<?php echo e($product->price); ?></td>
                                    <td class="text-center">
                                        <p class="qtypara">
                                            <input type="hidden" value="<?php echo e($product->rowId); ?>" id="hidden<?php echo e($product->id); ?>">                       
                                            <input type="number" min="1" value="<?php echo e($product->qty); ?>" class="form-control  qty<?php echo e($product->id); ?>" >
                                        </p>
                                    </td>

                                    <td class="text-center" id="price<?php echo e($product->id); ?>">Rs.<?php echo e(($product->price)*($product->qty)); ?></td>
                                    <td class="text-center">

                                      <form action="<?php echo e(route('cart.remove',$product->rowId)); ?>" method="post">
                                         <?php echo e(csrf_field()); ?>

                                         <button type="submit"><i class="icon_close_alt2"></i></button>                                
                                     </form>                                     
                                 </td>
                             </tr>
                             <script type="text/javascript">
    $(document).ready(function(){
        $(".qty<?php echo e($product->id); ?>").on('change keyup', function(){
            var a =   $(".qty<?php echo e($product->id); ?>").val();
            var b =   $("#hidden<?php echo e($product->id); ?>").val();
            $.ajax({
                url : '<?php echo e(URL::to('cart-update')); ?>',
                data: {'id': b,'qty':a},
                type : 'get',
                success : function(datas){
               console.log(datas);
                     $("#price<?php echo e($product->id); ?>").empty();
                    $("#price<?php echo e($product->id); ?>").append('<span id="price<?php echo e($product->id); ?>">Rs.'+datas.subtotal+'</span>');
                   $('#total').load(location.href + ' #total');
                    /*$("#grandtotal").empty();
                    $("#grandtotal").append('<span id="grandtotal">'++'</span></td>');*/
              }
          });
        });
    });
</script> 

                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="100%" class="text-center">No products added to cart.</td>
                                </tr>
                             <?php endif; ?>
                            <?php if(count(Cart::content())>0): ?>
                             <tr>
                                <td colspan="3">Grand Total</td>
                                
                                <td colspan="1" class="text-right" > <div id="total">
                 Rs.<?php echo e(Cart::total()); ?>

             </div></td>
             <td></td>
                             
                            </tr>
                            <?php endif; ?>
                          
                        </tbody>
                        
                        
                    </table>
                </div>
            </form>
            
        </div>
    
        <div class="col-sm-12">
            <div class="buttons">
                <button class="btn-primary " onclick="location.href='<?php echo e(route('shop')); ?>'">continue shopping</button>
                <?php if(count(Cart::content())>0): ?>
                <a type="button" href="<?php echo e(route('cart.destroy')); ?>" class="btn-primary">Clear shopping cart</a>
                
                <button type="button" class="btn-primary pull-right" onclick="location.href='<?php echo e(route('checkout.index')); ?>'">Proceed to Checkout</button>
                <?php endif; ?>
            </div>
        </div>
       <!--  <div class="col-sm-12">
           <div class="row">
               <div class="col-lg-4" style="margin-left: 30%">
                   <div class="cartable">
                       <h5>Cart Total</h5>
                       <table class="table">
                           <tbody>
                               <tr>
                                   <td class="text-left">Shipping</td>
                                   <td class="text-right">Rs. 0</td>
                               </tr>
                               <tr>
                                   <td class="text-left">Sub Total</td>
                                   <td class="text-right">Rs. <?php echo e(Cart::total()); ?></td>
                               </tr>
                           </tbody>
                       </table>
                       <div class="text-center">
                           <button type="button" class="btn-primary" onclick="location.href='<?php echo e(route('checkout.index')); ?>'">Proceed to Checkout</button>
                       </div>
                   </div>
               </div>
           </div>
       </div> -->
    </div>
</div>
<?php echo $__env->make('project.include.recommendation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<!-- checkout end here -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('project.pages.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>