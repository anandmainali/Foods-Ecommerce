<?php $__env->startSection('content'); ?>



    <!-- start page content -->
    <div class="page-content-wrapper">
        <div class="page-content">
            <div class="page-bar">
                <div class="page-title-breadcrumb">
                    <div class=" pull-left">
                        <div class="page-title">Associated List</div>
                        
                        <?php if(session()->has('success')): ?>
                        <div class="alert alert-success"><i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo e(session()->get('success')); ?></div>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
            <a href="<?php echo e(route('association.create')); ?>" class="btn btn-primary" role="button"><i class="fa fa-plus" aria-hidden="true"></i> Add Association</a>
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-topline-red">
                        <div class="card-head">
                            <header></header>
                            <div class="tools">
                                <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                                <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                                <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                            </div>
                        </div>
                        <div class="card-body ">
                             <table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle" id="example4">
                                <thead>
                                <tr>
                                    <th>Id</th>                                                                
                                    <th>Name</th>
                                    <th>Address</th>
                                    <th>Phone</th>
                                    <th>Info</th>                           
                                    <th>Action</th>                                 
                                </tr>
                            </thead>
                            <?php if(count($associations) > 0 ): ?>
                            <tbody>
                                <?php $__currentLoopData = $associations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$association): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($association->name); ?></td>
                                <td><?php echo e($association->address); ?></td>
                                <td><?php echo e($association->phone); ?></td>
                                <td> <?php echo html_entity_decode($association->info); ?></td>
                                <td>
                                    <?php echo Form::open(['method'=>'DELETE','action'=>['AssociationController@destroy',$association->id]]); ?>

                                    <?php echo Form::button('<i class="fa fa-trash"></i> Delete',['type'=>'submit','class'=>'btn btn-danger','return onClick'=>'confirm("Are you sure to delete?")']); ?>

                                    <?php echo Form::close(); ?>

                                    <a href='<?php echo e(route('association.edit',$association->id)); ?>'>
                                        <button class="btn btn-primary btn-sm">
                                            <i class="fa fa-edit"></i> Edit
                                        </button>
                                    </a>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>                        
                        <?php else: ?>
                        <tr>
                            <td colspan="100%"><h3>No branches found.</h3></td>
                        </tr>
                        <?php endif; ?>
                        </table>
                          <div class="paginate pull-right">
                              <?php echo e($associations->links()); ?>

                          </div>
                        </div>   
                        
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
    </div>
</div>

                                         
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>