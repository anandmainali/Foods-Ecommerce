<div class="row">
                        <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12 commontop text-center">
                            <p>Fresh Foods</p>
                            <h4>
                                <i class="icon_star_alt"></i>
                                <i class="icon_star_alt"></i>
                                <i class="icon_star_alt"></i>
                                Recommended Products
                                <i class="icon_star_alt"></i>
                                <i class="icon_star_alt"></i>
                                <i class="icon_star_alt"></i>
                            </h4>
                        </div>
                        <?php $__currentLoopData = $recommendations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommendation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
                            <div class="product-thumb">
                                <div class="image">
                                    <a href="<?php echo e(route('shop_detail',$recommendation->id)); ?>"><img src="<?php echo e($recommendation->image); ?>" alt="image" title="image" class="img-responsive" /></a>
                                    <div class="onhover onhover9"> 
                                        <div class="list-unstyled">   
                                        <?php if(auth()->check()): ?>                                  
                                                <form action="<?php echo e(route('wishlist.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="product_id" value="<?php echo e($recommendation->id); ?>" />
                                            <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>" />         
                                            <button type="submit"><i class="icon_heart"></i></button>   
                                        </form>
                                        <?php endif; ?>
                                            <form action="<?php echo e(route('cart.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($recommendation->id); ?>" />
                                            <input type="hidden" name="name" value="<?php echo e($recommendation->name); ?>" />
                                            <input type="hidden" name="image" value="<?php echo e($recommendation->image); ?>" />
                                            <input type="hidden" name="newprice" value="<?php echo e($recommendation->newprice); ?>" />
                                            <input type="hidden" name="qty" value="1" />
                                            <button type="submit"><i class="icon_cart"></i></button>    
                                        </form>                                         
                                        </div>
                                     </div>
                                </div>
                                <div class="caption">
                                    <h4><a href="<?php echo e(route('shop_detail',$recommendation->id)); ?>">Organic <span><?php echo e($recommendation->name); ?></span></a></h4>
                                    <p class="price">Rs.<?php echo e($recommendation->newprice); ?></p>
                                   
                                    
                                    <div class="button-group">                                       
                                        <button type="button"><i class="icon_heart"></i></button>
                                        <form action="<?php echo e(route('cart.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($recommendation->id); ?>" />
                                            <input type="hidden" name="name" value="<?php echo e($recommendation->name); ?>" />
                                            <input type="hidden" name="image" value="<?php echo e($recommendation->image); ?>" />
                                            <input type="hidden" name="newprice" value="<?php echo e($recommendation->newprice); ?>" />
                                            <input type="hidden" name="qty" value="1" />
                                            <button type="submit"><i class="icon_cart"></i></button>    
                                        </form>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        
                    </div>
                </div>
