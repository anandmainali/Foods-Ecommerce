

<?php echo $__env->make('project.include.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('project.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('project.include.slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('project.include.products', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('project.include.season', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('project.include.deals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('project.include.vegetable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('project.include.testimonials', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('project.include.shipping', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php echo $__env->make('project.include.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('project.include.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


