<?php $__env->startSection('content'); ?>



    <!-- start page content -->
    <div class="page-content-wrapper">
        <div class="page-content">
            <div class="page-bar">
                <div class="page-title-breadcrumb">
                    <div class=" pull-left">
                        <div class="page-title">Customer Comments List</div>
                        <?php if(session()->has('success')): ?>
                        <div class="alert alert-success"><i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo e(session()->get('success')); ?></div>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
            <a href="<?php echo e(route('customer.create')); ?>" class="btn btn-primary" role="button"><i class="fa fa-plus" aria-hidden="true"></i> Add Comment</a>
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-topline-red">
                        <div class="card-head">
                            <header></header>
                            <div class="tools">
                                <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                                <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                                <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                            </div>
                        </div>
                        <div class="card-body ">

                            <table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle" id="example4">
                                <thead>

                                <tr>
                                    <th>Id</th>
                                    <th>Customer Name</th>
                                    <th>Post</th>
                                    <th>Photo</th>
                                    <th>Comment</th> 
                                    <th>Action</th>                               
                                </tr>
                            </thead>
                           
                                <tbody>
                                    <?php if(count($customers) > 0): ?>
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                               <td><?php echo e(++$key); ?></td>
                               <td><?php echo e($customer->name); ?></td>
                               <td><?php echo e($customer->post); ?></td>
                               <td>
                                   <img src="/Images/Customers/<?php echo e($customer->photo); ?>" alt="" width="80">
                               </td>
                               <td><?php echo substr($customer->about,0,100).'...'; ?></td>
                               <td>
                                    <?php echo Form::open(['method'=>'DELETE','action'=>['HappyCustomerController@destroy',$customer->id]]); ?>

                                        <?php echo Form::button('<i class="fa fa-trash"></i> Delete',['type'=>'submit','class'=>'btn btn-danger','return onClick'=>'confirm("Are you sure to delete?")']); ?>

                                        <?php echo Form::close(); ?>

                                    <a href='<?php echo e(route('customer.edit',$customer->id)); ?>'>
                                        <button class="btn btn-primary btn-sm">
                                            <i class="fa fa-edit"></i> Edit
                                        </button>
                                    </a>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                            <?php else: ?>
                            <tr>
                                <td colspan="8"><h3>No comments found.</h3></td>
                            </tr>
                            <?php endif; ?>
                            
                                
                            
                        </table>
                      <div class="paginate pull-right">
                          <?php echo e($customers->links()); ?>

                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

                   
                        





                        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>