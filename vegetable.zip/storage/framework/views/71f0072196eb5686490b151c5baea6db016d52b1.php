<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper">
<div class="page-content"> 
        <div id="page-wrapper">
            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header" >
                            Add Association                        
                        </h1>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo Form::open(['method'=>'POST','action'=>'AssociationController@store','files'=>true]); ?>

                        <div class="col-md-6 ">
                                <div class="form-group">
                                    <?php echo Form::label('name','Name'); ?>

                                    <?php echo Form::text('name',null,['class'=>'form-control']); ?>

                                </div>
                                <div class="form-group">
                                    <?php echo Form::label('image','Logo'); ?>

                                    <?php echo Form::file('image',['class'=>'form-control']); ?>

                                </div>
                                <div class="form-group">
                                    <?php echo Form::label('address','Address'); ?>

                                    <?php echo Form::text('address',null,['class'=>'form-control']); ?>

                                </div>

                                <div class="form-group">
                                    <?php echo Form::label('phone','Phone'); ?>

                                    <?php echo Form::text('phone',null,['class'=>'form-control']); ?>

                                </div>

                                <div class="form-group">
                                    <?php echo Form::label('info','Info'); ?>

                                    <?php echo Form::textarea('info',null,['class'=>'form-control']); ?>

                                </div>                       
                        
                                <div class="form-group">                        
                                    <?php echo Form::submit('Create Association',['class'=>'btn btn-primary pull-right']); ?>

                                </div>
                        </div>
                        
                        <?php echo Form::close(); ?>

                        
                                                

                      </div>
                </div>
            </div>
        </div>
         </div>
        </div>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>