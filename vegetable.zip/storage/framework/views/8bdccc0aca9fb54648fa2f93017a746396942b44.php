<?php $__env->startSection('body'); ?>

    <?php echo $__env->make('project.include.bread-crumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <!-- shop container start here -->
    <div class="shop">
        <div class="container">
            <div class="row">
                <div class="sort col-sm-12 col-md-12 col-lg-12 col-xs-12">
                    
                    <p>Show result <?php echo e(count($products)); ?></p>
                </div>
                
                <div class="col-sm-10 offset-1" >
                    <div class="row">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="product-thumb">
                                <div class="image">
                                    <a href="<?php echo e(route('shop_detail',$product->id)); ?>"><img src="<?php echo e($product->image); ?>" alt="image" title="image" class="img-responsive" /></a>
                                    <div class="onhover onhover9"> 
                                        <div class="list-unstyled">                                     
                                                <?php if(auth()->check()): ?>                                        
                                                <form action="<?php echo e(route('wishlist.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" />
                                            <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>" />         
                                            <button type="submit"><i class="icon_heart"></i></button>   
                                        </form>
                                        <?php endif; ?>
                                            <form action="<?php echo e(route('cart.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                                            <input type="hidden" name="name" value="<?php echo e($product->name); ?>" />
                                            <input type="hidden" name="image" value="<?php echo e($product->image); ?>" />
                                            <input type="hidden" name="newprice" value="<?php echo e($product->newprice); ?>" />
                                            <input type="hidden" name="qty" value="1" />
                                            <button type="submit"><i class="icon_cart"></i></button>    
                                        </form>                                         
                                        </div>
                                     </div>
                                </div>
                                <div class="caption">
                                    <h4><a href="<?php echo e(route('shop_detail',$product->id)); ?>">Organic <span><?php echo e($product->name); ?></span></a></h4>
                                    <p class="price">Rs.<?php echo e($product->newprice); ?></p>
                                   
                                    
                                    <div class="button-group">                                       
                                        <?php if(auth()->check()): ?>                                        
                                                <form action="<?php echo e(route('wishlist.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" />
                                            <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>" />         
                                            <button type="submit"><i class="icon_heart"></i></button>   
                                        </form>
                                        <?php endif; ?>
                                        <form action="<?php echo e(route('cart.store')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                                            <input type="hidden" name="name" value="<?php echo e($product->name); ?>" />
                                            <input type="hidden" name="image" value="<?php echo e($product->image); ?>" />
                                            <input type="hidden" name="newprice" value="<?php echo e($product->newprice); ?>" />
                                            <input type="hidden" name="qty" value="1" />
                                            <button type="submit"><i class="icon_cart"></i></button>    
                                        </form>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!--pagination code start here-->
                    <!-- <ul class="list-inline pagination">
                        <li>
                            <span>Pages</span>
                        </li>
                        <li class="active">
                            <a href="#">1</a>
                        </li>
                        <li>
                            <a href="#">2</a>
                        </li>
                        <li>
                            <a href="#">3</a>
                        </li>
                        <li>
                            <a href="#">4</a>
                        </li>
                        <li>
                            <a href="#">5</a>
                        </li>
                        <li class="pull-right">
                            <a href="#" aria-label="Previous"><i class="arrow_left"></i></a>
                            <a href="#" aria-label="Next"><i class="arrow_right"></i></a>
                        </li>
                    </ul> -->
                    <!--pagination code end here-->
                </div>
                <div class="pull-right">
                        <?php echo e($products->links()); ?>

                        </div>
            </div>
            </div>
        </div>
    </div>



    </div>

    <!-- shop container end here -->


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('project.pages.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>