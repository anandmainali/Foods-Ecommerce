 <!-- bootstrap carousel -->

    <?php $__env->startSection('content'); ?> 
        <div class="custom-breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Meet Our Team</h2>
                    </div>
                </div>
            </div>
        </div><!--breadcrumb-->

        <div class="divide70"></div>
        
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container about-page">
                        <div class="row">
                <div class="col-md-4 margin30">
                    <div class="project-post">
                        <div class="item-img-wrap">
                            <img src="<?php echo e($member->photo); ?>" class="img-responsive" alt="">
                            
                        </div> 
                        <div class="team-desc col-md-12 col-sm-12">
                            <h3><?php echo e($member->name); ?> </h3>
                            <span> <?php echo e($member->post); ?> </span>
                        </div><!--team desc-->
                    </div><!--project post-->


                </div>
                <div class="col-md-6">
                    <div class="name">
                    <p>
                      <?php echo html_entity_decode($member->about); ?>

                    </p>
                    </div>
                    

                </div>
            </div><!--end row-->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('layouts.includes.appointment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    

         <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>