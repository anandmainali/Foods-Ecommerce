<!-- <div class="vegetable">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
				<div class="commontop text-left">
					<h4>
						Fresh Vegetables
						<i class="icon_star_alt"></i>
						<i class="icon_star_alt"></i>
						<i class="icon_star_alt"></i>
					</h4>
				</div>
				<div class="row">
					<div class="vegetables owl-carousel">
						<div class="item">
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="<?php echo e(URL::to('project/images/header1/fresh_veg1.png')); ?>" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Vegetables</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="<?php echo e(URL::to('project/images/header1/fresh_veg2.png')); ?>" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Vegetables</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="<?php echo e(URL::to('project/images/header1/fresh_veg3.png')); ?>" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Vegetables</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="<?php echo e(URL::to('project/images/header1/fresh_veg4.png')); ?>" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Vegetables</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_veg5.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Vegetables</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_veg6.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Vegetables</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_veg1.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Vegetables</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_veg2.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Vegetables</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_veg3.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Vegetables</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_veg4.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Vegetables</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_veg5.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Vegetables</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_veg6.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Vegetables</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
				<div class="commontop text-left">
					<h4>
						Fresh Fruits
						<i class="icon_star_alt"></i>
						<i class="icon_star_alt"></i>
						<i class="icon_star_alt"></i>
					</h4>
				</div>
				<div class="row">
					<div class="fruits owl-carousel">
						<div class="item">
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_fruit1.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Fruits</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_fruit2.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Fruits</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_fruit3.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Fruits</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_fruit4.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Fruits</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_fruit5.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Fruits</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_fruit6.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Fruits</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_fruit1.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Fruits</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_fruit2.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Fruits</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_fruit3.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Fruits</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_fruit4.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Fruits</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_fruit5.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Fruits</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="box">
									<div class="image">
										<a href="shop.html">
											<img src="images/header1/fresh_fruit6.png" alt="image" title="image" class="img-responsive" />
										</a>
									</div>
									<div class="caption">
										<h4>Title Here</h4>
										<p>Fruits</p>
										<div class="button-group">
											<button type="button"><i class="icon_heart"></i></button>
											<button type="button"><i class="fa fa-expand"></i></button>
											<button type="button"><i class="icon_cart"></i></button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
 -->
