 <!-- bootstrap carousel -->

    <?php $__env->startSection('content'); ?> 
<!-- Page Content -->

<div class="custom-breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Get Appointment</h2>                        
                    </div>
                </div>
            </div>
        </div><!--breadcrumb-->
        <div class="divide30"></div>

<div class="col-sm-6 col-sm-offset-3">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success"><i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo e(session()->get('success')); ?></div>
        <?php endif; ?>
</div>
  <section class="know-more">
    <div class="container">
    
<section id="login">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-6 col-md-offset-3">
              
                <div class="form-wrap">
                 <?php echo Form::open(['method'=>'POST','route'=>'appointment']); ?>

                
                        <div class="form-group">
                            <?php echo Form::label('name','Full Name'); ?>

                            <?php echo Form::text('name',null,['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('phone','Contact Number'); ?>

                            <?php echo Form::text('phone',null,['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('email','Email'); ?>

                            <?php echo Form::email('email',null,['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('age','Age'); ?>

                            <?php echo Form::text('age',null,['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('gender','Gender'); ?>

                            <?php echo Form::select('gender', ['Male' => 'Male', 'Female' => 'Female'], 'Male',['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('address','Address'); ?>

                            <?php echo Form::text('address',null,['class'=>'form-control']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('appointment_date','Appointment Date'); ?>

                            <?php echo Form::date('appointment_date', \Carbon\Carbon::now(),['class'=>'form-control']); ?>

                        </div>               
                
                        <div class="form-group">
                            <?php echo Form::label('reason','Reason for making appointment...'); ?>

                            <?php echo Form::textarea('reason',null,['class'=>'form-control']); ?>

                        </div>
                
                        <div class="form-group">                        
                            <?php echo Form::submit('Submit',['class'=>'btn btn-primary pull-right']); ?>

                        </div>
                
                
                <?php echo Form::close(); ?>

                
                














     <!--  <form class="form-style clearfix" role="form" action="<?php echo e(route('appointment')); ?>" method="post">
         <?php echo e(csrf_field()); ?>

       <div class="form-group">
         
         <input type="text" class="text-field form-control" name="name" placeholder="Patient Full Name">
       </div>
       <div class="form-group">
         
         <input type="tel" class="text-field form-control" placeholder="Contact Number" name="phone">
       </div>
       <div class="form-group">
         
         <input type="email" class="text-field form-control"name="email" placeholder="Email address">
       </div>
       <div class="form-group">
         
         <input type="text" class="form-control" name="age" placeholder="Your age">
       </div>
       <div class="form-group">
         
         <select name="gender" class="form-control">
     <option value="">Select you gender</option>
     <option value="Male">Male</option>
     <option value="Female">Female</option>
         </select>
       </div>
       <div class="form-group">
         
         <input type="text" class="text-field form-control" name="address" placeholder="Your Address">
       </div>
       <div class="form-group">
         <label for="date">Appointment Date</label>
         <input type="Date" class="form-control" name="appointment_date">
       </div>
     
     
     
       
       <div class="form-group">
         
         <textarea class="form-control" rows="7" name="reason" placeholder="Reason of making appointment...."></textarea>
       </div>
     <div class="form-group">
         <button type="submit" class="btn btn-lg btn-outline-inverse  submit" name="appointment_form">Submit</button>
     </div>
     <div class="form-group form-general-error-container"></div>
     
       </form> -->
                 
                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->
</section>
</div>
</section>

        <hr>
<br>

         <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.home-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>