 <!-- bootstrap carousel -->

    <?php $__env->startSection('content'); ?> 
<div class="custom-breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1>What is Rheumatology?</h1>
                    </div>
                </div>
            </div>
        </div><!--breadcrumb-->
        <div class="divide70"></div>

            <div class="container disorder">
                <div class="row">
                    <div class="col-md-11 col-md-offset-0.5">
                    A Rheumatologist treats arthritis, certain autoimmune diseases, musculoskeletal pain disorders and osteoporosis. There are more than 100 types of these diseases, including rheumatoid arthritis, osteoarthritis, gout, lupus, back pain, osteoporosis, fibromyalgia and tendonitis. Some of these are very serious diseases that can be difficult to diagnose and treat. If musculoskeletal pains are not severe or disabling and last just a few days, it makes sense to give the problem a reasonable chance to resolve on its own. But sometimes, pain in the joints, muscles or bones is severe or persists for more than a few days. At that point, you should see your physician. <br><br>

Rheumatic diseases are typically not easily identifiable in an early stage. Rheumatologists are specially trained to do the detective work necessary to discover the cause of swelling and pain in the joints. It is important to determine a correct diagnosis early so that appropriate treatment can begin early. Musculoskeletal disorders generally respond best to treatment in the early stages of the disease. <br><br>

Because some rheumatic diseases are complex, one visit to a rheumatologist may not be enough to determine a diagnosis and course of treatment. These diseases often change or evolve over time. Rheumatologists work closely with patients to identify the problem and design an individualized treatment program. <br><br>

A rheumatologist typically works with other physicians, acting as a consultant to advise another physician about a specific diagnosis and treatment plan. The rheumatologist acts as a manager for the musculoskeletal disease, relying upon the help of many skilled professionals including patient’s primary care doctors, nurses, physical and occupational therapists, psychologists and social workers. This teamwork is very important, since musculoskeletal disorders are chronic. <br><br>

Specialized care by and large saves time and money and reduces the severity of disease. A rheumatologist is specially trained to spot clues in the medical history and physical examination. The proper tests done early may save money in the long run. Prompt diagnosis and specially tailored treatment often save money and buy time in treating the disease. <br><br>

<h3>
Diseases</h3>

Diseases diagnosed or managed by rheumatologists include: <br>
<ul>
 <li>Degenerative arthropathies</li>
 <li>Osteoarthritis</li>
 <li>Inflammatory arthropathies</li>
 <li>Rheumatoid arthritis</li>
 <li>Spondyloarthropathies</li>
 <li>Ankylosing spondylitis</li>
 <li>Reactive arthritis (reactive arthropathy)</li>
 <li>Psoriatic arthropathy</li>
 <li>Enteropathic arthropathy</li>
 <li>Juvenile Idiopathic Arthritis (JIA)</li>
 <li>Crystal arthropathies: gout, pseudogout</li>
 <li>Septic arthritis</li>
</ul> <br>


Systemic conditions and connective tissue diseases <br>
<ul>
<li>Lupus </li>
<li>Ehlers-Danlos syndrome</li>
<li>Sjögren's syndrome</li>
<li>Scleroderma (systemic sclerosis)</li>
<li>Polymyositis</li>
<li>Dermatomyositis</li>
<li>Polymyalgia rheumatica</li>
<li>Mixed connective tissue disease</li>
<li>Relapsing polychondritis</li>
<li>Adult-onset Still's disease</li>
<li>Sarcoidosis</li>
<li>Fibromyalgia</li>
<li>Vasculitis</li>
</ul><br><br>
            </div>
            </div>
            </div>
        </section>
        <!--know more section end-->
 <?php echo $__env->make('layouts.includes.appointment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    

         <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>