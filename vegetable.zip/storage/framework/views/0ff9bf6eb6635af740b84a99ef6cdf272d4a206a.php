<?php $__env->startSection('content'); ?>

            <!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Appointment List</div>
                                <?php if(session()->has('success')): ?>
                        <div class="alert alert-success"><i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo e(session()->get('success')); ?></div>
                        <?php endif; ?>
                            </div>
                            <!-- <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index-2.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li><a class="parent-item" href="#">Appointment</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Appointment List</li>
                            </ol> -->
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card card-topline-red">
                                <div class="card-head">
                                    <header></header>
                                    <div class="tools">
                                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                                        <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                                        <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                                    </div>
                                </div>
                                <div class="card-body ">
                                    
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle" id="example4">
                                        <thead>
                                            <tr>
                                                <th>S.N.</th>
                                                <!-- <th>Date/Time</th> -->
                                                <th>Patient Name</th>
                                                <th>Phone</th>
                                                <!-- <th>Email</th> -->
                                                <!-- <th>Age</th>
                                                <th>Gender</th> -->
                                                <th>Address</th>                                                                        
                                                <th>Reason</th> 
                                                <th>Appointment Date</th>                        
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <?php if(count($appointments) > 0): ?>
                                        <tbody>
                                           
                                            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="odd gradeX">
                                                <td><?php echo e(++$key); ?></td>
                                               <!--  <td><?php echo e($appointment->created_at); ?></td> -->
                                                <td><?php echo e($appointment->name); ?></td>
                                                <td><?php echo e($appointment->phone); ?></td>
                                                <!-- <td><?php echo e($appointment->email); ?></td>
                                                <td><?php echo e($appointment->age); ?></td>
                                                <td><?php echo e($appointment->gender); ?></td> -->
                                                <td><?php echo e($appointment->address); ?></td>
                                                <td><?php echo e(substr($appointment->reason,0,75).'...'); ?></td>
                                                <td><?php echo e($appointment->appointment_date); ?></td>
                                                <td>
                                                   
                                                   <?php echo Form::open(['method'=>'DELETE','action'=>['AppointmentController@destroy',$appointment->id]]); ?>

                                                       <?php echo Form::button('<i class="fa fa-trash"></i> Delete',['type'=>'submit','class'=>'btn btn-danger','return onClick'=>'confirm("Are you sure to delete?")']); ?>

                                                       <?php echo Form::close(); ?>

                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            
                                            

                                        </tbody>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="100%"><h3>No appointments.</h3></td>
                                            </tr>
                                       <?php endif; ?>
                                    </table>
                                    <div class="paginate pull-right">
                                        <?php echo e($appointments->links()); ?>

                                    </div>
                                </div>
                            </div>
                          
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- end page content -->
            

                   
                        





                        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>