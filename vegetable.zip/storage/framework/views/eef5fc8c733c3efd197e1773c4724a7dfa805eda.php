<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Appointment</title>
</head>
<body>
<h1>Appointment Details</h1><br><br>
The detail information of patients are listed below:
<h3>Name: <?php echo e($name); ?></h3>
<h3>Contact No: <?php echo e($phone); ?></h3>
<h3>Email: <?php echo e($email); ?></h3>
<h3>Age: <?php echo e($age); ?></h3>
<h3>Gender: <?php echo e($gender); ?></h3>
<h3>Hospital: <?php echo e($hospital); ?></h3>
<h3>Address: <?php echo e($address); ?></h3>
<h3>Appointment Date: <?php echo e($appointment_date); ?></h3>
<h3>Reason: <?php echo e($reason); ?></h3>
</body>
</html>