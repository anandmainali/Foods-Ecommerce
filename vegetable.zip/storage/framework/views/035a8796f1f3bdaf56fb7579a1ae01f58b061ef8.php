<?php if(count($testimonials)>0): ?>
<div class="testi">
	<div class="container">		
		<div class="row">
			<div class="col-md-12 col-sm-12 col-lg-12 col-xs-12 commontop text-center">
				<p>People says</p>
				<h4>
					<i class="icon_star_alt"></i>
					<i class="icon_star_alt"></i>
					<i class="icon_star_alt"></i>
					testimonials
					<i class="icon_star_alt"></i>
					<i class="icon_star_alt"></i>
					<i class="icon_star_alt"></i>
				</h4>
			</div>
			<div class="col-sm-12 col-xs-12 owl-carousel testimonail">
				<?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="item">
					<div class="box text-center">
						<ul class="list-inline">
							<li>
								<img src="<?php echo e($testimonial->photo); ?>" style="height: 150px !important;width: 150px;" class="img-circle"  alt="img" title="img" />
							</li>
							
						</ul>
						<p><?php echo $testimonial->about; ?></p>
						<h4><i class="icon_profile"></i> <?php echo e($testimonial->name); ?></h4>
						<span>(<?php echo e($testimonial->post); ?>)</span>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>		
	</div>
</div>
<?php endif; ?>
<br>
