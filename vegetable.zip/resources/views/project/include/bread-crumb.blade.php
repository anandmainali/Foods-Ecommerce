<!-- bread-crumb start here -->
<div class="bread-crumb">
    <img src="{{URL::to('project/images/top-banner.jpg')}}" class="img-responsive" alt="banner-top" title="banner-top">
    <div class="container">
        <div class="matter">
            <h2><span>Organic</span> Confirmation</h2>
            <ul class="list-inline">
                <li>
                    <a >HOME</a>
                </li>
                <li>
                    <a >Confirmation</a>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- bread-crumb end here -->