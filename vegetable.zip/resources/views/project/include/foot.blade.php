{{--<!-- jquery -->
<script src="{{URL::to('/project/js/jquery.2.1.1.min.js')}}"></script>
<!-- bootstrap js -->
<script src="{{URL::to('/project/bootstrap/js/bootstrap.min.js')}}"></script>
<!--bootstrap select-->
<script src="{{URL::to('/project/js/dist/js/bootstrap-select.js')}}"></script>
<script src="{{URL::to('/project/js/check.js')}}"></script>

<!--internal js-->
<script src="{{URL::to('/project/js/internal.js')}}"></script>
<!-- owlcarousel js -->
<script src="{{URL::to('/project/js/owl-carousel/owl.carousel.min.js')}}"></script>
<script src="{{URL::to('/project/js/preetycheble/prettyCheckable.min.js')}}"></script>
<script src="{{URL::to('/project/js/preetycheble/timer.js')}}"></script>



<!--Gallery js code-->
<script src="{{URL::to('/project/js/photo-gallery.js')}}"></script>



</body>

</html>--}}


<!--footer end here -->

<!-- jquery -->
<script src="{{URL::to('/project/js/jquery.2.1.1.min.js')}}"></script>
<!-- bootstrap js -->
<script src="{{URL::to('/project/bootstrap/js/bootstrap.min.js')}}"></script>
<!--bootstrap select-->
<script src="{{URL::to('/project/js/dist/js/bootstrap-select.js')}}"></script>
<!--internal js-->
<script src="{{URL::to('/project/js/internal.js')}}"></script>
<!-- owlcarousel js -->
<script src="{{URL::to('/project/js/owl-carousel/owl.carousel.min.js')}}"></script>
</body>

</html>
