<div class="shipping">
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-sm-4 col-lg-4 col-xs-12">
				<div class="box">
					<img class="img-responsive" src="{{URL::to('project/images/header1/icon1.png')}}" alt="icon" title="icon">
					<h4>We Support 24/7</h4>
					<p>Nullam tempus luctus erat vitae volutpat. Donec rhoncus.</p>
				</div>
			</div>
			<div class="col-md-4 col-sm-4 col-lg-4 col-xs-12">
				<div class="box">
					<img class="img-responsive" src="{{URL::to('project/images/header1/icon2.png')}}" alt="icon" title="icon">
					<h4>Daily Updates</h4>
					<p>Nullam tempus luctus erat vitae volutpat. Donec rhoncus.</p>
				</div>
			</div>
			<div class="col-md-4 col-sm-4 col-lg-4 col-xs-12">
				<div class="box">
					<img class="img-responsive" src="{{URL::to('project/images/header1/icon3.png')}}" alt="icon" title="icon">
					<h4>Free Shipping</h4>
					<p>Nullam tempus luctus erat vitae volutpat. Donec rhoncus.</p>
				</div>
			</div>
		</div>
	</div>
</div>
