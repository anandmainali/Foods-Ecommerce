$(document).ready(function(){
	"use strict";  
 $('input.checkclass').prettyCheckable({
		color: 'red'
	  });
});
